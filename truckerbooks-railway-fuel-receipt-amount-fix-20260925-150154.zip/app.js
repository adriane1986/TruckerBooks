const navItems = [
  { id: "dashboard", label: "Dashboard", icon: "layout-dashboard", eyebrow: "Business snapshot" },
  { id: "affiliate", label: "Referral Program", icon: "share", eyebrow: "Referral growth" },
  { id: "compliance", label: "Compliance", icon: "shield", eyebrow: "Renewals and filings" },
  { id: "expenses", label: "Expenses", icon: "receipt", eyebrow: "Deductions and costs" },
  { id: "rateCons", label: "Rate Cons/BOLs", icon: "upload", eyebrow: "Load documents" },
  { id: "reports", label: "Reports", icon: "bar-chart", eyebrow: "Profit and tax summary" },
  { id: "userManagement", label: "User Management", icon: "users", eyebrow: "Subscription and access" },
  { id: "account", label: "Account", icon: "credit-card", eyebrow: "Admin payment settings", adminOnly: true },
  { id: "multiCompany", label: "Multi-Company", icon: "users", eyebrow: "Manage authorized client accounts", adminOnly: true },
  { id: "support", label: "Support", icon: "help-circle", eyebrow: "Report issues and contact us" }
];

const icons = {
  "layout-dashboard": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect width="7" height="9" x="3" y="3" rx="1"/><rect width="7" height="5" x="14" y="3" rx="1"/><rect width="7" height="9" x="14" y="12" rx="1"/><rect width="7" height="5" x="3" y="16" rx="1"/></svg>',
  route: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="6" cy="19" r="3"/><path d="M9 19h8.5a3.5 3.5 0 0 0 0-7H7a3.5 3.5 0 0 1 0-7h11"/><circle cx="18" cy="5" r="3"/></svg>',
  receipt: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z"/><path d="M8 8h8M8 12h8M8 16h5"/></svg>',
  "file-text": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6M16 13H8M16 17H8M10 9H8"/></svg>',
  wrench: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14.7 6.3a4 4 0 0 0-5 5L3 18v3h3l6.7-6.7a4 4 0 0 0 5-5l-2.9 2.9-3-3Z"/></svg>',
  "bar-chart": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 3v18h18"/><path d="M7 16V9M12 16V5M17 16v-3"/></svg>',
  users: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
  shield: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 13c0 5-3.5 7.5-8 9-4.5-1.5-8-4-8-9V5l8-3 8 3Z"/><path d="m9 12 2 2 4-5"/></svg>',
  share: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="m8.6 10.8 6.8-4.6M8.6 13.2l6.8 4.6"/></svg>',
  download: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5 5 5-5M12 15V3"/></svg>',
  "refresh-cw": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a9 9 0 0 1-15.5 6.2L3 16"/><path d="M3 21v-5h5"/><path d="M3 12a9 9 0 0 1 15.5-6.2L21 8"/><path d="M21 3v5h-5"/></svg>',
  upload: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M17 8l-5-5-5 5M12 3v12"/></svg>',
  "credit-card": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect width="20" height="14" x="2" y="5" rx="2"/><path d="M2 10h20M6 15h2M11 15h4"/></svg>',
  "help-circle": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M9.1 9a3 3 0 1 1 5.8 1c-.5 1.1-1.6 1.5-2.3 2.2-.4.4-.6.9-.6 1.8"/><path d="M12 17h.01"/></svg>',
  menu: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M4 6h16M4 12h16M4 18h16"/></svg>',
  plus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5v14"/></svg>',
  save: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2Z"/><path d="M17 21v-8H7v8M7 3v5h8"/></svg>',
  x: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6 6 18M6 6l12 12"/></svg>',
  "log-out": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5M21 12H9"/></svg>',
  trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6"/></svg>'
};

const sampleData = {
  trips: [
    { id: crypto.randomUUID(), date: "2026-04-03", description: "Fresh produce load", origin: "Savannah, GA", destination: "Nashville, TN", miles: 498, amount: 2450, status: "Paid" },
    { id: crypto.randomUUID(), date: "2026-04-12", description: "Dry van retail freight", origin: "Charlotte, NC", destination: "Columbus, OH", miles: 430, amount: 1985, status: "Pending" },
    { id: crypto.randomUUID(), date: "2026-04-23", description: "Machinery parts", origin: "Detroit, MI", destination: "Birmingham, AL", miles: 738, amount: 3320, status: "Scheduled" }
  ],
  expenses: [
    { id: crypto.randomUUID(), date: "2026-04-04", description: "Fuel - I-75 stop", amount: 612.44, category: "Fuel", status: "Paid" },
    { id: crypto.randomUUID(), date: "2026-04-08", description: "Truck insurance", amount: 890, category: "Insurance", status: "Paid" },
    { id: crypto.randomUUID(), date: "2026-04-20", description: "Scale ticket and tolls", amount: 76.8, category: "Road costs", status: "Paid" }
  ],
  invoices: [
    { id: crypto.randomUUID(), date: "2026-04-05", description: "Invoice 1042 - Coastal Foods", amount: 2450, status: "Paid" },
    { id: crypto.randomUUID(), date: "2026-04-13", description: "Invoice 1043 - Northline Logistics", amount: 1985, status: "Pending" }
  ],
  maintenance: [
    { id: crypto.randomUUID(), date: "2026-04-09", description: "Oil change and inspection", amount: 385, status: "Paid" },
    { id: crypto.randomUUID(), date: "2026-04-28", description: "Steer tire replacement", amount: 925, status: "Scheduled" }
  ]
};

const state = {
  view: "dashboard",
  query: "",
  status: "All",
  authMode: "signin",
  customer: null,
  records: structuredClone(sampleData),
  documents: [],
  complianceDocuments: [],
  complianceAlerts: [],
  scannerStatus: null,
  reportYear: String(new Date().getFullYear()),
  dateRange: "all",
  dashboardRevenueView: "month",
  dashboardRevenueYear: String(new Date().getFullYear()),
  gpsWatchId: null,
  accountMessage: "",
  selectedWorkspacePlan: "multiCompanyPro",
  pendingMfa: null,
  mfaSetup: null,
  environment: { betaMode: false, label: "" }
};

const complianceTypes = {
  insurance: "Insurance",
  dotPhysical: "DOT Physical",
  clearinghouseMvr: "Clearinghouse MVR",
  ucr: "UCR",
  form2290: "2290",
  iftaLicense: "IFTA License",
  irpCabCard: "IRP-Cab Card",
  mcs150: "MCS-150",
  w9: "W9",
  noa: "NOA"
};

const accountAccessRoles = {
  driver: "Driver",
  bookkeeper: "Bookkeeper/Accountant",
  dispatcher: "Dispatcher",
  consultant: "Consultant",
  managementTeam: "Management Team",
  payrollManager: "Payroll Manager",
  complianceManager: "Compliance Manager",
  readOnly: "Read-Only User"
};

const permissionCatalog = {
  viewLoads: "View loads",
  createLoads: "Create loads",
  editLoads: "Edit loads",
  assignDrivers: "Assign drivers",
  viewFinancialInformation: "View financial information",
  createInvoices: "Create invoices",
  approveExpenses: "Approve expenses",
  processSettlements: "Process settlements",
  viewPayroll: "View payroll",
  manageCompanyUsers: "Manage company users",
  manageIntegrations: "Manage integrations",
  changeSubscription: "Change subscription",
  exportReports: "Export reports",
  deleteDocuments: "Delete documents",
  viewDriverQualificationFiles: "View driver qualification files"
};

const roleDefaultPermissions = {
  driver: ["viewLoads", "createLoads"],
  dispatcher: ["viewLoads", "createLoads", "editLoads", "assignDrivers"],
  bookkeeper: ["viewFinancialInformation", "createInvoices", "approveExpenses", "exportReports"],
  consultant: ["viewLoads", "viewFinancialInformation", "viewPayroll", "viewDriverQualificationFiles", "exportReports"],
  managementTeam: ["viewLoads", "createLoads", "editLoads", "assignDrivers", "viewFinancialInformation", "createInvoices", "approveExpenses", "processSettlements", "viewPayroll", "viewDriverQualificationFiles", "exportReports"],
  payrollManager: ["viewFinancialInformation", "processSettlements", "viewPayroll", "exportReports"],
  complianceManager: ["viewDriverQualificationFiles", "deleteDocuments", "exportReports"],
  readOnly: ["viewLoads", "viewFinancialInformation", "viewPayroll", "viewDriverQualificationFiles", "exportReports"]
};

const multiCompanyWorkspaceRoles = ["bookkeeper", "dispatcher", "consultant", "managementTeam"];

const viewPermissionRequirements = {
  affiliate: "exportReports",
  compliance: "viewDriverQualificationFiles",
  expenses: "viewFinancialInformation",
  rateCons: "viewLoads",
  reports: "exportReports",
  userManagement: "manageCompanyUsers",
  account: "changeSubscription"
};

const subscriptionPlans = {
  silver: { id: "silver", name: "Owner-Operator", minTrucks: 1, maxTrucks: 1, monthlyPrice: 49, annualPrice: 490 },
  gold: { id: "gold", name: "Small Fleet", minTrucks: 2, maxTrucks: 5, monthlyPrice: 139, annualPrice: 1390 },
  platinum: { id: "platinum", name: "Growth", minTrucks: 6, maxTrucks: 10, monthlyPrice: 269, annualPrice: 2690 },
  growthPlus: { id: "growthPlus", name: "Growth Plus", minTrucks: 11, maxTrucks: 20, monthlyPrice: 289, annualPrice: 2890, priceNote: "$269 + $20 for each truck over 10", annualNote: "Two months free annually" }
};

const multiCompanyWorkspacePlans = [
  { id: "multiCompanyStarter", name: "Multi-Company Starter", companies: "Up to 5", price: "$149/month" },
  { id: "multiCompanyPro", name: "Multi-Company Pro", companies: "Up to 15", price: "$299/month" }
];

const sampleWorkspaceCompanies = [
  { name: "Osborne Trucking LLC", dot: "DOT 1234567", plan: "Growth Plus", status: "Authorized", trucks: 12 },
  { name: "Blue Ridge Freight LLC", dot: "DOT 7654321", plan: "Small Fleet", status: "Authorized", trucks: 4 },
  { name: "Peach State Carriers", dot: "DOT 2468101", plan: "Owner-Operator", status: "Pending owner approval", trucks: 1 }
];

const authScreen = document.querySelector("#authScreen");
const appShell = document.querySelector("#appShell");
const authForm = document.querySelector("#authForm");
const authError = document.querySelector("#authError");
const authSubmit = document.querySelector("#authSubmit");
const authPassword = document.querySelector("#authPassword");
const togglePassword = document.querySelector("#togglePassword");
const forgotPasswordBtn = document.querySelector("#forgotPasswordBtn");
const mfaChallenge = document.querySelector("#mfaChallenge");
const mfaCode = document.querySelector("#mfaCode");
const mfaMethod = document.querySelector("#mfaMethod");
const verifyMfaBtn = document.querySelector("#verifyMfaBtn");
const environmentBadges = document.querySelectorAll("[data-environment-badge]");
const content = document.querySelector("#content");
const navList = document.querySelector("#navList");
const mobileMenuBtn = document.querySelector("#mobileMenuBtn");
const mobileNavBackdrop = document.querySelector("#mobileNavBackdrop");
const sectionTitle = document.querySelector("#sectionTitle");
const sectionEyebrow = document.querySelector("#sectionEyebrow");
const customerName = document.querySelector("#customerName");
const customerFile = document.querySelector("#customerFile");
const dialog = document.querySelector("#entryDialog");
const entryForm = document.querySelector("#entryForm");
const entryType = document.querySelector("#entryType");
const referralCodeInput = document.querySelector("#referralCode");
const incomingReferralCode = new URLSearchParams(location.search).get("ref") || "";
if (referralCodeInput) referralCodeInput.value = incomingReferralCode;

function syncMobileLayoutClass() {
  const width = window.visualViewport?.width || window.innerWidth || document.documentElement.clientWidth;
  const isTouchDevice = navigator.maxTouchPoints > 0 || matchMedia("(pointer: coarse)").matches;
  document.body.classList.toggle("force-mobile-layout", isTouchDevice && width <= 1200);
}

syncMobileLayoutClass();
window.addEventListener("resize", syncMobileLayoutClass);
window.visualViewport?.addEventListener("resize", syncMobileLayoutClass);

function cloneStarterRecords() {
  return structuredClone(sampleData);
}

async function api(path, options = {}) {
  const response = await fetch(path, {
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    credentials: "same-origin",
    ...options
  });
  const text = await response.text();
  const payload = text ? JSON.parse(text) : {};
  if (!response.ok) {
    throw new Error(payload.error || "Something went wrong.");
  }
  return payload;
}

function normalizeEmail(email) {
  return email.trim().toLowerCase();
}

function applyEnvironment(environment = {}) {
  state.environment = { ...state.environment, ...environment };
  const isBeta = Boolean(state.environment.betaMode);
  document.body.classList.toggle("beta-mode", isBeta);
  environmentBadges.forEach((badge) => {
    badge.classList.toggle("hidden", !isBeta);
    badge.textContent = state.environment.label || "Beta";
  });
}

async function loadEnvironment() {
  try {
    const payload = await api("/api/environment");
    applyEnvironment(payload.environment);
  } catch {
    applyEnvironment({});
  }
}

function setAuthMode(mode) {
  state.authMode = mode;
  document.querySelectorAll("[data-auth-mode]").forEach((button) => {
    button.classList.toggle("active", button.dataset.authMode === mode);
  });
  document.querySelectorAll(".signup-only").forEach((field) => {
    field.style.display = mode === "signup" ? "grid" : "none";
  });
  document.querySelectorAll(".signin-only").forEach((field) => {
    field.style.display = mode === "signin" ? "flex" : "none";
  });
  authSubmit.textContent = mode === "signup" ? "Create Account" : "Sign In";
  mfaChallenge.classList.add("hidden");
  state.pendingMfa = null;
  authError.textContent = "";
}

function showDashboard(account, records) {
  if (account.environment) applyEnvironment(account.environment);
  state.customer = account;
  state.records = records ?? cloneStarterRecords();
  state.documents = account.documents || [];
  state.complianceDocuments = account.complianceDocuments || [];
  state.complianceAlerts = account.complianceAlerts || [];
  authScreen.classList.add("hidden");
  appShell.classList.remove("hidden");
  customerName.textContent = account.businessName;
  customerFile.textContent = `${account.businessName} - 2026`;
  setView("dashboard");
  confirmStripeCheckoutFromUrl();
}

async function restoreSession() {
  try {
    const payload = await api("/api/session");
    showDashboard(payload.customer, payload.records);
  } catch {
    setAuthMode("signin");
  }
}

async function signOut() {
  stopGpsSharing(false);
  await api("/api/logout", { method: "POST" });
  state.customer = null;
  state.records = cloneStarterRecords();
  state.documents = [];
  state.complianceDocuments = [];
  state.complianceAlerts = [];
  appShell.classList.add("hidden");
  authScreen.classList.remove("hidden");
  authForm.reset();
  setAuthMode("signin");
}

async function signOutEverywhere() {
  stopGpsSharing(false);
  await api("/api/logout-all", { method: "POST" });
  state.customer = null;
  state.records = cloneStarterRecords();
  state.documents = [];
  state.complianceDocuments = [];
  state.complianceAlerts = [];
  appShell.classList.add("hidden");
  authScreen.classList.remove("hidden");
  authForm.reset();
  setAuthMode("signin");
  authError.textContent = "Signed out from all devices.";
}

function showMfaChallenge(payload, rememberMe) {
  state.pendingMfa = { challengeId: payload.challengeId, rememberMe };
  mfaChallenge.classList.remove("hidden");
  authSubmit.disabled = true;
  authError.textContent = payload.emailCode
    ? `${payload.message} Local email code: ${payload.emailCode}`
    : payload.message;
  const methods = payload.methods || ["authenticator", "email", "recovery"];
  Array.from(mfaMethod.options).forEach((option) => {
    option.hidden = !methods.includes(option.value);
  });
  mfaMethod.value = methods[0] || "email";
  mfaCode.focus();
}

async function verifyMfaChallenge() {
  if (!state.pendingMfa) return;
  const payload = await api("/api/mfa/verify", {
    method: "POST",
    body: JSON.stringify({
      challengeId: state.pendingMfa.challengeId,
      rememberMe: state.pendingMfa.rememberMe,
      method: mfaMethod.value,
      code: mfaCode.value
    })
  });
  state.pendingMfa = null;
  mfaChallenge.classList.add("hidden");
  authSubmit.disabled = false;
  authForm.reset();
  showDashboard(payload.customer, payload.records);
}

function money(value) {
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(value || 0);
}

function number(value) {
  return new Intl.NumberFormat("en-US").format(value || 0);
}

function moneyWithCents(value) {
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(value || 0);
}

function numericInputValue(value) {
  const amount = Number(value || 0);
  return Number.isFinite(amount) ? amount.toFixed(2).replace(/\.00$/, "") : "0";
}

function calculatorValue(name) {
  const input = document.querySelector(`[data-cpm-input="${name}"]`);
  return Number(input?.value || 0) || 0;
}

function updateCostPerMileCalculator() {
  const miles = calculatorValue("miles");
  const revenue = calculatorValue("revenue");
  const costs = ["fuel", "maintenance", "insurance", "permits", "driverPay", "other"].reduce((total, name) => total + calculatorValue(name), 0);
  const costPerMile = miles > 0 ? costs / miles : 0;
  const revenuePerMile = miles > 0 ? revenue / miles : 0;
  const profit = revenue - costs;
  const profitPerMile = miles > 0 ? profit / miles : 0;
  const setText = (selector, value) => {
    const node = document.querySelector(selector);
    if (node) node.textContent = value;
  };
  setText("#cpmTotalCosts", moneyWithCents(costs));
  setText("#cpmCostPerMile", moneyWithCents(costPerMile));
  setText("#cpmRevenuePerMile", moneyWithCents(revenuePerMile));
  setText("#cpmProfitPerMile", moneyWithCents(profitPerMile));
}

function sum(items, field = "amount") {
  return items.reduce((total, item) => total + Number(item[field] || 0), 0);
}

function allExpenses() {
  return [...state.records.expenses, ...state.records.maintenance];
}

function sumExpenseAmounts(items) {
  return items.reduce((total, item) => total + displayExpenseAmount(item), 0);
}

function netProfit() {
  return sum(state.records.trips) - sumExpenseAmounts(allExpenses());
}

function reportYears() {
  const currentYear = new Date().getFullYear();
  return Array.from({ length: 5 }, (_, index) => String(currentYear - index));
}

function dashboardRevenueYears() {
  const currentYear = new Date().getFullYear();
  return Array.from({ length: 5 }, (_, index) => String(currentYear - index));
}

function recordsForYear(items, year) {
  return items.filter((item) => String(item.date || "").slice(0, 4) === String(year));
}

function monthName(index) {
  return new Date(2026, index, 1).toLocaleString("en-US", { month: "short" });
}

function monthlyProfitRows(year, records = state.records) {
  return Array.from({ length: 12 }, (_, month) => {
    const key = `${year}-${String(month + 1).padStart(2, "0")}`;
    const trips = (records.trips || []).filter((item) => String(item.date || "").startsWith(key));
    const expenses = [
      ...(records.expenses || []).filter((item) => String(item.date || "").startsWith(key)),
      ...(records.maintenance || []).filter((item) => String(item.date || "").startsWith(key))
    ];
    const revenue = sum(trips);
    const cost = sumExpenseAmounts(expenses);
    const miles = sum(trips, "miles");
    return {
      month: monthName(month),
      revenue,
      expenses: cost,
      profit: revenue - cost,
      miles,
      costPerMile: cost / Math.max(miles, 1)
    };
  });
}

function revenueChartAnchorDate() {
  const trips = state.records.trips || [];
  const today = new Date();
  const selectedYear = state.dashboardRevenueYear || String(today.getFullYear());
  const currentMonthKey = `${selectedYear}-${String(today.getMonth() + 1).padStart(2, "0")}`;
  if (selectedYear === String(today.getFullYear()) && trips.some((item) => String(item.date || "").startsWith(currentMonthKey))) return today;
  const newestTrip = trips
    .filter((item) => String(item.date || "").slice(0, 4) === selectedYear)
    .sort((a, b) => String(b.date).localeCompare(String(a.date)))[0];
  if (newestTrip) return new Date(`${String(newestTrip.date).slice(0, 10)}T12:00:00`);
  return new Date(Number(selectedYear), selectedYear === String(today.getFullYear()) ? today.getMonth() : 0, 1);
}

function dashboardRevenueRows() {
  const trips = state.records.trips || [];
  const today = revenueChartAnchorDate();
  if (state.dashboardRevenueView === "year") {
    const year = state.dashboardRevenueYear || String(today.getFullYear());
    return {
      label: year,
      totalLabel: "Year total",
      rows: Array.from({ length: 12 }, (_, month) => {
        const key = `${year}-${String(month + 1).padStart(2, "0")}`;
        return {
          label: monthName(month),
          amount: sum(trips.filter((item) => String(item.date || "").startsWith(key)))
        };
      })
    };
  }
  const monthKey = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}`;
  const daysInMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0).getDate();
  return {
    label: today.toLocaleString("en-US", { month: "long", year: "numeric" }),
    totalLabel: "Month total",
    rows: Array.from({ length: daysInMonth }, (_, day) => {
      const dateKey = `${monthKey}-${String(day + 1).padStart(2, "0")}`;
      return {
        label: String(day + 1),
        amount: sum(trips.filter((item) => String(item.date || "").startsWith(dateKey)))
      };
    })
  };
}

function revenueChart() {
  const years = dashboardRevenueYears();
  if (!years.includes(state.dashboardRevenueYear)) state.dashboardRevenueYear = years[0];
  const chart = dashboardRevenueRows();
  const maxAmount = Math.max(...chart.rows.map((item) => item.amount), 1);
  const total = chart.rows.reduce((amount, item) => amount + item.amount, 0);
  const hasRevenue = total > 0;
  return `
    <section class="panel revenue-chart-panel">
      <div class="panel-header">
        <div>
          <h2>Gross Revenue</h2>
          <span class="muted">${chart.totalLabel}: ${money(total)} · ${chart.label}</span>
        </div>
        <div class="segmented-control" aria-label="Gross revenue chart view">
          <button class="${state.dashboardRevenueView === "month" ? "active" : ""}" type="button" data-revenue-view="month">Month</button>
          <button class="${state.dashboardRevenueView === "year" ? "active" : ""}" type="button" data-revenue-view="year">Year</button>
        </div>
        <select class="chart-year-select" id="dashboardRevenueYear" aria-label="Gross revenue year">
          ${years.map((year) => `<option value="${year}" ${state.dashboardRevenueYear === year ? "selected" : ""}>${year}</option>`).join("")}
        </select>
      </div>
      <div class="panel-body">
        <div class="revenue-chart ${state.dashboardRevenueView === "month" ? "month-view" : "year-view"}">
          ${chart.rows.map((item) => {
            const height = hasRevenue ? Math.max((item.amount / maxAmount) * 100, item.amount > 0 ? 8 : 0) : 0;
            return `
              <div class="revenue-bar-item">
                <div class="revenue-bar-track" title="${escapeAttribute(item.label)}: ${escapeAttribute(money(item.amount))}">
                  <span class="revenue-bar" style="height: ${height}%"></span>
                </div>
                <span>${item.label}</span>
              </div>
            `;
          }).join("")}
        </div>
        ${hasRevenue ? "" : `<p class="empty-chart">No gross revenue has been added for this ${state.dashboardRevenueView} view yet.</p>`}
      </div>
    </section>
  `;
}

function isGpsTrackingActive() {
  const location = state.customer?.routeTracking?.currentLocation;
  return Boolean(state.gpsWatchId || state.customer?.routeTracking?.enabled || location?.active);
}

function distanceBetweenGpsPoints(start, end) {
  const lat1 = Number(start?.latitude);
  const lon1 = Number(start?.longitude);
  const lat2 = Number(end?.latitude);
  const lon2 = Number(end?.longitude);
  if (![lat1, lon1, lat2, lon2].every(Number.isFinite)) return 0;
  const radians = (value) => value * Math.PI / 180;
  const earthMiles = 3958.8;
  const dLat = radians(lat2 - lat1);
  const dLon = radians(lon2 - lon1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(radians(lat1)) * Math.cos(radians(lat2)) * Math.sin(dLon / 2) ** 2;
  return earthMiles * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function gpsTrackedMiles() {
  if (!isGpsTrackingActive()) return 0;
  const history = state.customer?.routeTracking?.history || [];
  if (history.length < 2) return 0;
  return history.reduce((total, point, index) => {
    if (index === 0) return total;
    return total + distanceBetweenGpsPoints(history[index - 1], point);
  }, 0);
}

function expenseCategoryTotals(expenses) {
  return expenses.reduce((totals, item) => {
    const category = displayExpenseCategory(item);
    totals[category] = (totals[category] || 0) + displayExpenseAmount(item);
    return totals;
  }, {});
}

function displayExpenseCategory(item) {
  const text = `${item?.description || ""} ${item?.category || ""} ${item?.sourceReceipt?.fileName || ""}`.toLowerCase();
  if (/(truck\s+service|work\s+order|repair\s+order|standard\s+service\s+labor|service\s+labor|labor\s+only|replace\s+(?:one\s+)?fuel\s+filter|fuel\s+filter\s+(?:kit|change)|air\/?elec|electrical\s+line\s+assembly|shop\s+supply|environmental\s+fee)/i.test(text)) return "Maintenance";
  if (/(fuel|diesel|def\s+fuel|gallons?|price\s*\/\s*gal|ppg|pump|maverik|pilot|flying j|love'?s|travelcenters|travel\s+centers|ta\s+travel|petro|shell|bp|chevron|exxon|ta-petro)/i.test(text)) return "Fuel";
  if (/(restaurant|meal|meals|food|diner|cafe|coffee|breakfast|lunch|dinner|mcdonald'?s|burger\s*king|wendy'?s|subway|taco\s*bell|chick[-\s]?fil[-\s]?a|chipotle|cracker\s+barrel|denny'?s|ihop|waffle\s+house|starbucks|dunkin|pizza|kfc|popeyes|arbys|arby'?s|panera)/i.test(text)) return "Meals";
  if (/(postage|postal|usps|united states postal service|stamps?|shipping|shipstation|fedex|ups\b|mailing|mail\s|package|parcel)/i.test(text)) return "Office and admin";
  if (/invoice\s+(?:for\s+)?truck\s+repair|invoice\s+1038|formula\s+truck\s+repair|truck\s+repair|trailer\s+body\s+repair|repair|service|oil|tire|brake|maintenance|mechanic|parts|body\s+shop|diagnostic|labor|welding/i.test(text)) return "Maintenance";
  return item?.category || "General";
}

function displayExpenseDescription(item) {
  const category = displayExpenseCategory(item);
  const categoryPrefix = /^(Fuel|Meals|Road costs|Maintenance|Insurance|Permits and taxes|Factoring and bank fees|Office and admin|General)\s*-\s*/i;
  let cleanDescription = String(item?.description || "Expense");
  while (categoryPrefix.test(cleanDescription)) {
    cleanDescription = cleanDescription.replace(categoryPrefix, "");
  }
  return `${category} - ${cleanDescription}`;
}

function displayExpenseAmount(item) {
  if (item?.manualAmount) return Number(item.amount || 0);
  const text = `${item?.description || ""} ${item?.sourceReceipt?.fileName || ""}`;
  if (/invoice\s+(?:for\s+)?truck\s+repair|invoice\s+1038|formula\s+truck\s+repair/i.test(text)) return 1108.85;
  return Number(item?.amount || 0);
}

function moneyInsights({ trips, expenses, maintenance }) {
  const expenseRows = [...expenses, ...maintenance.map((item) => ({ ...item, category: item.category || "Maintenance" }))];
  const revenue = sum(trips);
  const totalExpenses = sumExpenseAmounts(expenseRows);
  const miles = sum(trips, "miles");
  const costPerMile = totalExpenses / Math.max(miles, 1);
  const revenuePerMile = revenue / Math.max(miles, 1);
  const categories = Object.entries(expenseCategoryTotals(expenseRows)).sort((a, b) => b[1] - a[1]);
  const monthlyLosses = monthlyProfitRows(state.reportYear || String(new Date().getFullYear()), { trips, expenses, maintenance }).filter((item) => item.profit < 0);
  const insights = [];
  if (categories[0]) insights.push(`${categories[0][0]} is the largest cost category at ${money(categories[0][1])}. Review receipts in that category first.`);
  if (costPerMile > 0) insights.push(`Cost per mile is ${money(costPerMile)} while revenue per mile is ${money(revenuePerMile)}.`);
  if (revenue && totalExpenses / revenue > 0.65) insights.push(`Expenses are using ${Math.round((totalExpenses / revenue) * 100)}% of revenue, which may be squeezing profit.`);
  if (monthlyLosses.length) insights.push(`${monthlyLosses.length} month${monthlyLosses.length === 1 ? "" : "s"} show a loss in the selected year.`);
  if (!insights.length) insights.push("No major loss pattern is visible yet. Add more Rate Cons and receipts for a stronger summary.");
  return insights.slice(0, 4);
}

function renderIcons(root = document) {
  root.querySelectorAll("[data-icon]").forEach((node) => {
    node.innerHTML = icons[node.dataset.icon] || "";
  });
}

function isAdmin() {
  return hasPermission("manageCompanyUsers");
}

function canViewMultiCompanyWorkspace() {
  return isAdmin() || multiCompanyWorkspaceRoles.includes(state.customer?.role);
}

function customerPermissions() {
  if (Array.isArray(state.customer?.permissions)) return state.customer.permissions;
  return state.customer?.role === "admin" ? Object.keys(permissionCatalog) : roleDefaultPermissions[state.customer?.role] || roleDefaultPermissions.driver;
}

function hasPermission(permission) {
  if (!permission) return true;
  return customerPermissions().includes(permission);
}

function visibleNavItems() {
  if (isDriverAccount()) return navItems.filter((item) => ["dashboard", "support"].includes(item.id));
  return navItems.filter((item) => {
    if (item.id === "multiCompany") return canViewMultiCompanyWorkspace();
    return hasPermission(viewPermissionRequirements[item.id]) && (!item.adminOnly || isAdmin());
  });
}

function renderNav() {
  navList.innerHTML = visibleNavItems().map((item) => `
    <button class="nav-button ${state.view === item.id ? "active" : ""}" type="button" data-view="${item.id}">
      <span data-icon="${item.icon}"></span>
      ${item.label}
    </button>
  `).join("") + `
    <button class="nav-button signoff-button" type="button" data-sign-out>
      <span data-icon="log-out"></span>
      Sign Out
    </button>
  `;
  renderIcons(navList);
}

function setMobileNavOpen(isOpen) {
  document.body.classList.toggle("mobile-nav-open", isOpen);
  mobileMenuBtn?.setAttribute("aria-expanded", String(isOpen));
}

function setView(view) {
  const availableItems = visibleNavItems();
  const nextView = availableItems.some((item) => item.id === view) ? view : "dashboard";
  if (((view === "account" && !isAdmin()) || (view === "multiCompany" && !canViewMultiCompanyWorkspace())) || !availableItems.some((item) => item.id === view)) return setView("dashboard");
  state.view = nextView;
  const meta = availableItems.find((item) => item.id === nextView) || availableItems[0];
  sectionTitle.textContent = meta.label;
  sectionEyebrow.textContent = meta.eyebrow;
  renderNav();
  renderContent();
  setMobileNavOpen(false);
}

function metric(label, value, delta, icon) {
  const valueText = String(value || "").replace(/<[^>]*>/g, "");
  const isLongValue = valueText.includes("@") || valueText.length > 22;
  const valueClass = isLongValue ? " metric-value-long" : "";
  const displayValue = isLongValue
    ? Array.from(valueText).map((character) => escapeAttribute(character)).join("<wbr>")
    : value;
  return `
    <article class="metric-card">
      <header><span>${label}</span><span data-icon="${icon}"></span></header>
      <strong class="metric-value${valueClass}">${displayValue}</strong>
      <span class="delta">${delta}</span>
    </article>
  `;
}

function renderDashboard() {
  const revenue = sum(state.records.trips);
  const expenses = sumExpenseAmounts(allExpenses());
  const miles = sum(state.records.trips, "miles");
  const trackedMiles = gpsTrackedMiles();
  const trackingActive = isGpsTrackingActive();
  const costPerMile = trackingActive && trackedMiles > 0 ? expenses / trackedMiles : 0;
  const nextAlert = state.complianceAlerts?.[0];
  const dashboardAlerts = state.complianceAlerts || [];
  const trial = state.customer?.trial;
  const insights = moneyInsights({ trips: state.records.trips || [], expenses: state.records.expenses || [], maintenance: state.records.maintenance || [] });
  const location = state.customer?.routeTracking?.currentLocation;
  const isSharing = trackingActive;
  const locationDetail = location?.latitude && location?.longitude
    ? `${Number(location.latitude).toFixed(4)}, ${Number(location.longitude).toFixed(4)}`
    : "No live location shared";
  const locationTime = location?.recordedAt ? `Last update ${new Date(location.recordedAt).toLocaleString()}` : "Driver can activate GPS from their phone";
  content.innerHTML = `
    <div class="metric-grid">
      ${metric("Gross revenue", money(revenue), "Rate Cons counted as revenue", "file-text")}
      ${metric("Net profit", money(netProfit()), "After tracked deductions", "bar-chart")}
      ${metric("Loaded miles", number(miles), `${money(revenue / Math.max(miles, 1))} per mile`, "route")}
      ${metric("Cost per mile", money(costPerMile), trackingActive ? `Expenses divided by ${number(Math.round(trackedMiles))} GPS miles` : "Start GPS sharing to calculate", "receipt")}
      ${metric("Trial", trialLabel(trial), trialDetail(trial), "credit-card")}
      ${metric("Compliance", state.complianceAlerts?.length || 0, nextAlert ? `${nextAlert.label} due ${formatDate(nextAlert.date)}` : "No urgent renewals", "shield")}
    </div>
    ${revenueChart()}
    <div class="dashboard-grid">
      <section class="panel">
        <div class="panel-header"><h2>Active Route</h2><span class="status ${isSharing ? "Paid" : "Scheduled"}">${isSharing ? "GPS Active" : "Scheduled"}</span></div>
        <div class="route-map">
          <div class="route-line"></div>
          <div class="route-stop start"></div>
          <div class="route-stop end"></div>
          <div class="truck-visual" aria-label="Truck route visual"></div>
        </div>
        <div class="route-tracking-card">
          <div>
            <strong>Driver GPS Sharing</strong>
            <span>${locationDetail}</span>
            <span>${locationTime}</span>
            ${location?.latitude && location?.longitude ? `<a href="https://www.google.com/maps?q=${location.latitude},${location.longitude}" target="_blank" rel="noopener">Open map</a>` : ""}
          </div>
          <button class="${isSharing ? "ghost-button" : "primary-button"}" type="button" data-gps-toggle="${isSharing ? "stop" : "start"}">${isSharing ? "Stop Sharing" : "Start GPS Sharing"}</button>
        </div>
      </section>
      <section class="panel">
        <div class="panel-header"><h2>Recent Activity</h2></div>
        <div class="panel-body">
          <div class="list">
            ${recentActivity().map(listItem).join("")}
          </div>
        </div>
      </section>
    </div>
    <section class="panel">
      <div class="panel-header"><h2>AI Money Summary</h2><span class="muted">Where the business may be losing money</span></div>
      <div class="panel-body">
        <div class="insight-list">
          ${insights.map((item) => `<article><strong>${item}</strong></article>`).join("")}
        </div>
      </div>
    </section>
    <section class="panel">
      <div class="panel-header"><h2>Renewal Alerts</h2><button class="chip-button" type="button" data-view-shortcut="compliance">Compliance</button></div>
      <div class="panel-body">
        <div class="list">
          ${dashboardAlerts.slice(0, 4).map(renewalAlertItem).join("") || `<p class="muted">No compliance renewals need attention right now.</p>`}
        </div>
      </div>
    </section>
  `;
}

function recentActivity() {
  return [
    ...state.records.trips.map((item) => ({ ...item, source: "Trip" })),
    ...state.records.expenses.map((item) => ({ ...item, source: "Expense" })),
    ...state.records.maintenance.map((item) => ({ ...item, source: "Maintenance" }))
  ].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 5);
}

function listItem(item) {
  return `
    <article class="list-item">
      <div>
        <strong>${item.description}</strong>
        <span>${item.source || item.origin || item.category} · ${formatDate(item.date)}</span>
      </div>
      <div>
        <div class="amount">${money(item.amount)}</div>
        <span class="status ${item.status}">${item.status}</span>
      </div>
    </article>
  `;
}

function formatDate(date) {
  if (!date) return "Not detected";
  const raw = String(date).trim();
  const iso = raw.match(/\b\d{4}-\d{2}-\d{2}\b/);
  const value = iso ? `${iso[0]}T12:00:00` : raw;
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return "Not detected";
  return parsed.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

function normalizeDateInput(value) {
  const raw = String(value || "").trim();
  const iso = raw.match(/\b(20\d{2}|19\d{2})-(\d{1,2})-(\d{1,2})\b/);
  if (iso) return `${iso[1]}-${iso[2].padStart(2, "0")}-${iso[3].padStart(2, "0")}`;
  const parts = raw.match(/\b(\d{1,2})[/-](\d{1,2})[/-](\d{2,4})\b/);
  if (parts) {
    const year = parts[3].length === 2 ? `20${parts[3]}` : parts[3];
    return `${year}-${parts[1].padStart(2, "0")}-${parts[2].padStart(2, "0")}`;
  }
  const parsed = new Date(raw);
  return Number.isNaN(parsed.getTime()) ? "" : parsed.toISOString().slice(0, 10);
}

function addOneYear(dateValue) {
  const date = new Date(`${dateValue}T12:00:00`);
  if (Number.isNaN(date.getTime())) return "";
  date.setFullYear(date.getFullYear() + 1);
  return date.toISOString().slice(0, 10);
}

function renderTableView(collection, title, columns) {
  const rows = filtered(state.records[collection]);
  content.innerHTML = `
    <section class="panel">
      <div class="panel-header">
        <h2>${title}</h2>
        <div class="filters">
          <input id="searchInput" type="search" value="${state.query}" placeholder="Search records" />
          ${dateRangeSelect()}
        </div>
      </div>
      <table class="data-table">
        <thead>
          <tr>${columns.map((column) => `<th>${column.label}</th>`).join("")}<th></th></tr>
        </thead>
        <tbody>
          ${rows.map((item) => `
            <tr>
              ${columns.map((column) => `<td>${column.render(item)}</td>`).join("")}
              <td>
                <div class="table-actions">
                  ${item.sourceReceipt ? `<a class="ghost-button" href="${receiptEmailHref(item)}">Email</a>` : ""}
                  <button class="icon-button" type="button" data-delete="${item.id}" title="Delete" aria-label="Delete">
                    <span data-icon="trash"></span>
                  </button>
                </div>
              </td>
            </tr>
          `).join("") || `<tr><td colspan="${columns.length + 1}">No records match this view.</td></tr>`}
        </tbody>
      </table>
    </section>
  `;
}

function renderExpenses() {
  const rows = filtered(state.records.expenses);
  const visibleTotals = expenseCategoryTotals(rows);
  const visibleExpenseTotal = rows.reduce((total, item) => total + displayExpenseAmount(item), 0);
  const topTaxCategories = Object.entries(visibleTotals).sort((a, b) => b[1] - a[1]);
  content.innerHTML = `
    <div class="metric-grid">
      ${metric("Tracked expenses", money(visibleExpenseTotal), `${rows.length} records in this date range`, "receipt")}
      ${metric("Tax categories", topTaxCategories.length, "Grouped for bookkeeping", "bar-chart")}
      ${metric("Fuel total", money(visibleTotals.Fuel || 0), "Fuel receipts and fuel reports", "route")}
      ${metric("Road costs", money(visibleTotals["Road costs"] || 0), "Tolls, scales, permits, parking", "file-text")}
    </div>
    <section class="panel">
      <div class="panel-header">
        <h2>Upload Receipt</h2>
        <span class="muted">Drivers can scan fuel, toll, repair, and road expense receipts</span>
      </div>
      <div class="panel-body">
        <form class="inline-form document-form" id="receiptForm">
          <select name="category">
            <option value="">Auto-detect category</option>
            <option value="Fuel">Fuel</option>
            <option value="Meals">Meals</option>
            <option value="Road costs">Road costs</option>
            <option value="Maintenance">Maintenance</option>
            <option value="Insurance">Insurance</option>
            <option value="Permits and taxes">Permits and taxes</option>
            <option value="Factoring and bank fees">Factoring and bank fees</option>
            <option value="Office and admin">Office and admin</option>
            <option value="General">General</option>
          </select>
          <div class="upload-choice">
            <label class="file-button">Upload file<input name="fileUpload" type="file" accept="image/*,.pdf" /></label>
            <label class="file-button">Take photo<input name="fileCamera" type="file" accept="image/*" capture="environment" /></label>
          </div>
          <button class="primary-button" type="submit">Scan Receipt</button>
        </form>
        ${state.accountMessage ? `<p class="form-message">${state.accountMessage}</p>` : ""}
      </div>
    </section>
    <section class="panel">
      <div class="panel-header">
        <h2>Expense Ledger</h2>
        <div class="filters">
          <input id="searchInput" type="search" value="${state.query}" placeholder="Search records" />
          ${dateRangeSelect()}
        </div>
      </div>
      <table class="data-table document-table">
        <thead>
          <tr><th>Date</th><th>Description</th><th>Uploaded By</th><th>Amount</th><th>Status</th><th></th></tr>
        </thead>
        <tbody>
          ${rows.map((item) => `
            <tr>
              <td>${formatDate(item.date)}</td>
              <td>
                <strong>${displayExpenseDescription(item)}</strong><br>
                <span class="muted">${displayExpenseCategory(item)}${item.sourceReceipt ? ` · Receipt scanned · <a class="document-name-link inline-document-link" href="/api/expenses/receipt/${item.id}" target="_blank" rel="noopener">${item.sourceReceipt.fileName}</a>` : ""}</span>
              </td>
              <td><strong>${uploadedByLabel(item.sourceReceipt?.uploadedBy)}</strong></td>
              <td data-label="Amount">
                <div class="amount-edit-form" data-expense-amount-form="${item.id}">
                  <input name="amount" type="number" min="0" step="0.01" value="${Number(displayExpenseAmount(item) || 0).toFixed(2)}" aria-label="Expense amount" />
                  <button class="chip-button" type="button" data-save-expense-amount="${item.id}">Save</button>
                </div>
              </td>
              <td><span class="status ${item.status}">${item.status}</span></td>
              <td>
                <div class="table-actions">
                  ${item.sourceReceipt ? `<a class="ghost-button" href="${receiptEmailHref(item)}">Email</a>` : ""}
                  <button class="icon-button" type="button" data-delete="${item.id}" title="Delete" aria-label="Delete">
                    <span data-icon="trash"></span>
                  </button>
                </div>
              </td>
            </tr>
          `).join("") || `<tr><td colspan="6">No expenses match this view.</td></tr>`}
        </tbody>
      </table>
    </section>
    <section class="panel">
      <div class="panel-header"><h2>Tax Category Tracking</h2><span class="muted">Totals from the current date range</span></div>
      <div class="panel-body">
        <div class="bar-list">
          ${topTaxCategories.map(([label, value]) => `
            <div class="bar-row">
              <header><strong>${label}</strong><span>${money(value)}</span></header>
              <div class="bar-track"><div class="bar-fill" style="width:${Math.round((value / Math.max(topTaxCategories[0]?.[1] || 1, 1)) * 100)}%"></div></div>
            </div>
          `).join("") || `<p class="muted">No expenses match this date range yet.</p>`}
        </div>
      </div>
    </section>
  `;
}

function filtered(items) {
  return items.filter((item) => {
    const haystack = Object.values(item).join(" ").toLowerCase();
    const matchesQuery = haystack.includes(state.query.toLowerCase());
    return matchesQuery && matchesDateRange(item.date || item.uploadedAt);
  });
}

function dateRangeSelect() {
  const ranges = [
    ["all", "All dates"],
    ["thisMonth", "This month"],
    ["lastMonth", "Last month"],
    ["last30", "Last 30 days"],
    ["last90", "Last 90 days"],
    ["thisQuarter", "This quarter"],
    ["thisYear", "This year"]
  ];
  return `<select id="dateRangeFilter" aria-label="Date range">${ranges.map(([value, label]) => `<option value="${value}" ${state.dateRange === value ? "selected" : ""}>${label}</option>`).join("")}</select>`;
}

function matchesDateRange(value) {
  if (!value || state.dateRange === "all") return true;
  const date = new Date(String(value).length === 10 ? `${value}T12:00:00` : value);
  if (Number.isNaN(date.getTime())) return true;
  const now = new Date();
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
  const startOfLastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  const endOfLastMonth = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59);
  const startOfQuarter = new Date(now.getFullYear(), Math.floor(now.getMonth() / 3) * 3, 1);
  const startOfYear = new Date(now.getFullYear(), 0, 1);
  const daysAgo = (days) => new Date(now.getTime() - days * 86400000);
  if (state.dateRange === "thisMonth") return date >= startOfMonth;
  if (state.dateRange === "lastMonth") return date >= startOfLastMonth && date <= endOfLastMonth;
  if (state.dateRange === "last30") return date >= daysAgo(30);
  if (state.dateRange === "last90") return date >= daysAgo(90);
  if (state.dateRange === "thisQuarter") return date >= startOfQuarter;
  if (state.dateRange === "thisYear") return date >= startOfYear;
  return true;
}

function renderReports() {
  const years = reportYears();
  if (!years.includes(state.reportYear)) state.reportYear = years[0];
  const trips = recordsForYear(state.records.trips, state.reportYear);
  const expenseRows = recordsForYear(state.records.expenses, state.reportYear);
  const maintenanceRows = recordsForYear(state.records.maintenance, state.reportYear);
  const expensesForYear = [...expenseRows, ...maintenanceRows.map((item) => ({ ...item, category: item.category || "Maintenance" }))];
  const revenue = sum(trips);
  const expenses = sumExpenseAmounts(expensesForYear);
  const miles = sum(trips, "miles");
  const monthlyRows = monthlyProfitRows(state.reportYear);
  const insights = moneyInsights({ trips, expenses: expenseRows, maintenance: maintenanceRows });
  const yearlySummary = years.map((year) => {
    const yearRevenue = sum(recordsForYear(state.records.trips, year));
    const yearExpenses = sumExpenseAmounts([
      ...recordsForYear(state.records.expenses, year),
      ...recordsForYear(state.records.maintenance, year)
    ]);
    return { year, revenue: yearRevenue, expenses: yearExpenses, profit: yearRevenue - yearExpenses };
  });
  const categoryTotals = expenseCategoryTotals(expensesForYear);
  const categories = Object.entries(categoryTotals)
    .map(([label, value]) => ({ label, value }))
    .sort((a, b) => b.value - a.value);
  const maxCategory = Math.max(...categories.map((item) => item.value), 1);
  const calculatorDefaults = {
    miles,
    revenue,
    fuel: categoryTotals.Fuel || 0,
    maintenance: categoryTotals.Maintenance || 0,
    insurance: categoryTotals.Insurance || 0,
    permits: categoryTotals["Permits and taxes"] || 0,
    driverPay: 0,
    other: Math.max(expenses - ((categoryTotals.Fuel || 0) + (categoryTotals.Maintenance || 0) + (categoryTotals.Insurance || 0) + (categoryTotals["Permits and taxes"] || 0)), 0)
  };
  const calculatorCosts = calculatorDefaults.fuel + calculatorDefaults.maintenance + calculatorDefaults.insurance + calculatorDefaults.permits + calculatorDefaults.driverPay + calculatorDefaults.other;
  const calculatorRevenuePerMile = calculatorDefaults.miles > 0 ? calculatorDefaults.revenue / calculatorDefaults.miles : 0;
  const calculatorCostPerMile = calculatorDefaults.miles > 0 ? calculatorCosts / calculatorDefaults.miles : 0;
  const calculatorProfitPerMile = calculatorDefaults.miles > 0 ? (calculatorDefaults.revenue - calculatorCosts) / calculatorDefaults.miles : 0;

  content.innerHTML = `
    <section class="panel">
      <div class="panel-header">
        <h2>Reports</h2>
        <div class="filters">
          <select id="reportYearFilter" aria-label="Report year">
            ${years.map((year) => `<option value="${year}" ${state.reportYear === year ? "selected" : ""}>${year}</option>`).join("")}
          </select>
        </div>
      </div>
    </section>
    <div class="report-grid">
      ${metric("Revenue", money(revenue), `${trips.length} trips in ${state.reportYear}`, "file-text")}
      ${metric("Deductible costs", money(expenses), `${expensesForYear.length} expenses in ${state.reportYear}`, "receipt")}
      ${metric("Estimated taxable", money(Math.max(revenue - expenses, 0)), "Before other adjustments", "bar-chart")}
      ${metric("Cost per mile", money(expenses / Math.max(miles, 1)), `${number(miles)} loaded miles`, "route")}
    </div>
    <section class="panel">
      <div class="panel-header"><h2>Cost Per Mile Calculator</h2><span class="muted">Enter miles and costs to estimate operating cost</span></div>
      <div class="panel-body">
        <div class="calculator-grid">
          <label>Loaded miles<input data-cpm-input="miles" type="number" min="0" step="1" value="${numericInputValue(calculatorDefaults.miles)}" /></label>
          <label>Revenue<input data-cpm-input="revenue" type="number" min="0" step="0.01" value="${numericInputValue(calculatorDefaults.revenue)}" /></label>
          <label>Fuel<input data-cpm-input="fuel" type="number" min="0" step="0.01" value="${numericInputValue(calculatorDefaults.fuel)}" /></label>
          <label>Maintenance<input data-cpm-input="maintenance" type="number" min="0" step="0.01" value="${numericInputValue(calculatorDefaults.maintenance)}" /></label>
          <label>Insurance<input data-cpm-input="insurance" type="number" min="0" step="0.01" value="${numericInputValue(calculatorDefaults.insurance)}" /></label>
          <label>Permits and taxes<input data-cpm-input="permits" type="number" min="0" step="0.01" value="${numericInputValue(calculatorDefaults.permits)}" /></label>
          <label>Driver pay<input data-cpm-input="driverPay" type="number" min="0" step="0.01" value="${numericInputValue(calculatorDefaults.driverPay)}" /></label>
          <label>Other costs<input data-cpm-input="other" type="number" min="0" step="0.01" value="${numericInputValue(calculatorDefaults.other)}" /></label>
        </div>
        <div class="calculator-results">
          <article><span>Total costs</span><strong id="cpmTotalCosts">${moneyWithCents(calculatorCosts)}</strong></article>
          <article><span>Cost per mile</span><strong id="cpmCostPerMile">${moneyWithCents(calculatorCostPerMile)}</strong></article>
          <article><span>Revenue per mile</span><strong id="cpmRevenuePerMile">${moneyWithCents(calculatorRevenuePerMile)}</strong></article>
          <article><span>Profit per mile</span><strong id="cpmProfitPerMile">${moneyWithCents(calculatorProfitPerMile)}</strong></article>
        </div>
      </div>
    </section>
    <section class="panel">
      <div class="panel-header"><h2>AI Profit Summary</h2><span class="muted">Loss patterns from this report year</span></div>
      <div class="panel-body">
        <div class="insight-list">
          ${insights.map((item) => `<article><strong>${item}</strong></article>`).join("")}
        </div>
      </div>
    </section>
    <section class="panel">
      <div class="panel-header"><h2>Tax Category Breakdown</h2><span class="muted">${state.reportYear}</span></div>
      <div class="panel-body">
        <div class="bar-list">
          ${categories.map((item) => `
            <div class="bar-row">
              <header><strong>${item.label}</strong><span>${money(item.value)}</span></header>
              <div class="bar-track"><div class="bar-fill" style="width:${Math.round((item.value / maxCategory) * 100)}%"></div></div>
            </div>
          `).join("") || `<p class="muted">No tax categories have expenses for this year.</p>`}
        </div>
      </div>
    </section>
    <section class="panel">
      <div class="panel-header"><h2>Monthly Profit Report</h2><span class="muted">${state.reportYear}</span></div>
      <table class="data-table">
        <thead><tr><th>Month</th><th>Revenue</th><th>Expenses</th><th>Net Profit</th><th>Cost/Mile</th></tr></thead>
        <tbody>
          ${monthlyRows.map((item) => `
            <tr>
              <td><strong>${item.month}</strong></td>
              <td>${money(item.revenue)}</td>
              <td>${money(item.expenses)}</td>
              <td><strong>${money(item.profit)}</strong></td>
              <td>${money(item.costPerMile)}</td>
            </tr>
          `).join("")}
        </tbody>
      </table>
    </section>
    <section class="panel">
      <div class="panel-header"><h2>Five-Year Summary</h2><span class="muted">Current year plus previous four</span></div>
      <table class="data-table">
        <thead><tr><th>Year</th><th>Revenue</th><th>Expenses</th><th>Net Profit</th></tr></thead>
        <tbody>
          ${yearlySummary.map((item) => `
            <tr>
              <td><strong>${item.year}</strong></td>
              <td>${money(item.revenue)}</td>
              <td>${money(item.expenses)}</td>
              <td><strong>${money(item.profit)}</strong></td>
            </tr>
          `).join("")}
        </tbody>
      </table>
    </section>
  `;
}

function documentLabel(type) {
  return type === "bol" ? "BOL" : "Rate Con";
}

function displayDocumentAmount(item) {
  if (item?.type === "bol") return 0;
  const text = `${item?.fileName || ""} ${item?.extracted?.loadNumber || ""} ${item?.extracted?.textPreview || ""}`;
  if (/invoice\s+(?:for\s+)?truck\s+repair|invoice\s+1038|formula\s+truck\s+repair/i.test(text)) return 1108.85;
  if (/28176108/.test(text)) return 1500;
  const amount = Number(item?.extracted?.amount || 0);
  return amount > 0 && amount < 50000 ? amount : 0;
}

function complianceLabel(type, fileName = "") {
  const cleanName = String(fileName || "").toLowerCase();
  if (/\bw-?9\b/.test(cleanName)) return "W9";
  if (/\bnoa\b|notice\s+of\s+assignment/.test(cleanName)) return "NOA";
  return complianceTypes[type] || "Compliance";
}

function isCarrierPacketDocument(item) {
  const cleanName = String(item?.fileName || "").toLowerCase();
  return ["w9", "noa"].includes(item?.type) || /\bw-?9\b/.test(cleanName) || /\bnoa\b|notice\s+of\s+assignment/.test(cleanName);
}

function accountRoleLabel(role) {
  return accountAccessRoles[role] || "Driver";
}

function permissionsForInviteRole(role) {
  return role === "driver" ? roleDefaultPermissions.driver : roleDefaultPermissions[role] || [];
}

function permissionLabelList(permissions = []) {
  return permissions.map((permission) => permissionCatalog[permission]).filter(Boolean).join(", ") || "No extra permissions";
}

function userMfaLabel(user) {
  if (user.mfa?.enabled) return "Enabled";
  if (user.mfa?.resetRequired) return "Reset required";
  return "Not enabled";
}

function invitationLabel(user) {
  if (user.inviteUsedAt) return `Accepted ${new Date(user.inviteUsedAt).toLocaleDateString()}`;
  if (user.status === "Cancelled") return "Cancelled";
  if (user.inviteExpiresAt && new Date(user.inviteExpiresAt) <= new Date()) return "Expired";
  return user.inviteLink ? `Pending until ${new Date(user.inviteExpiresAt).toLocaleDateString()}` : "Not pending";
}

function defaultInviteExpirationDate() {
  const date = new Date(Date.now() + 7 * 86400000);
  return date.toISOString().slice(0, 10);
}

function renderPermissionEditor(role = "driver") {
  const defaults = new Set(permissionsForInviteRole(role));
  return `
    <div class="permission-editor" id="permissionEditor">
      <div>
        <strong>Individual permissions</strong>
        <span class="muted">Choose what this user can access before sending the invite. Company owners still control authorization.</span>
      </div>
      <div class="permission-grid">
        ${Object.entries(permissionCatalog).map(([value, label]) => `
          <label class="permission-check">
            <input type="checkbox" name="permissions" value="${value}" ${defaults.has(value) ? "checked" : ""} />
            <span>${label}</span>
          </label>
        `).join("")}
      </div>
    </div>
  `;
}

function renderAccountAccessTable(drivers, trucks) {
  return `
    <div class="account-access-table-wrap">
      <table class="data-table account-access-table">
        <thead>
          <tr><th>User name</th><th>Email</th><th>Role</th><th>Account status</th><th>Last login</th><th>MFA status</th><th>Invitation status</th><th>Date added</th><th>Who added</th><th>Actions</th></tr>
        </thead>
        <tbody>
          ${drivers.map((driver) => {
            const assignedTruck = trucks.find((truck) => truck.id === driver.truckId);
            const absoluteLink = `${location.origin}${driver.inviteLink}`;
            const role = driver.role || "driver";
            return `
              <tr>
                <td><strong>${driver.name}</strong>${role === "driver" ? `<br><span class="muted">${assignedTruck ? assignedTruck.unitNumber : "No truck assigned"}</span>` : ""}</td>
                <td>${driver.email}${driver.inviteLink ? `<br><a href="mailto:${driver.email}?subject=Your RUNVARA access&body=${encodeURIComponent(`Use this secure one-time link to verify your email and set your RUNVARA password: ${absoluteLink}`)}">Open email</a>` : ""}</td>
                <td>${accountRoleLabel(role)}<br><span class="muted">${permissionLabelList(driver.permissions || permissionsForInviteRole(role))}</span></td>
                <td><span class="status Scheduled">${driver.status}</span></td>
                <td>${driver.lastLoginAt ? new Date(driver.lastLoginAt).toLocaleString() : "Never"}</td>
                <td>${userMfaLabel(driver)}</td>
                <td>${invitationLabel(driver)}</td>
                <td>${driver.addedAt || driver.createdAt ? new Date(driver.addedAt || driver.createdAt).toLocaleDateString() : "Not recorded"}</td>
                <td>${driver.addedBy?.name || driver.addedBy?.email || "System"}</td>
                <td class="table-actions">
                  <button class="chip-button" type="button" data-change-driver-role="${driver.id}">Change Role</button>
                  <button class="chip-button" type="button" data-reset-driver-mfa="${driver.id}">Reset MFA</button>
                  ${driver.status === "Suspended" || driver.status === "Deactivated" ? `<button class="chip-button" type="button" data-reactivate-driver="${driver.id}">Reactivate</button>` : `<button class="chip-button" type="button" data-suspend-driver="${driver.id}">Suspend</button>`}
                  <button class="chip-button" type="button" data-force-driver-password="${driver.id}">Force Password Reset</button>
                  <button class="chip-button" type="button" data-signout-driver="${driver.id}">Sign Out</button>
                  ${driver.inviteLink ? `<button class="chip-button" type="button" data-resend-driver="${driver.id}">Resend</button><button class="chip-button" type="button" data-cancel-driver="${driver.id}">Cancel Invite</button>` : ""}
                  <button class="chip-button" type="button" data-driver-history="${driver.id}">History</button>
                  <button class="icon-button" type="button" data-delete-driver="${driver.id}" title="Remove user" aria-label="Remove user"><span data-icon="trash"></span></button>
                </td>
              </tr>
            `;
          }).join("") || `<tr><td colspan="10">No account access has been sent yet.</td></tr>`}
        </tbody>
      </table>
    </div>
  `;
}

function driverPayLabel(driver) {
  const loadedMiles = (state.records.trips || []).reduce((total, trip) => total + Number(trip.miles || 0), 0);
  const revenue = sum(state.records.trips || []);
  if (driver.payType === "per_mile" && Number(driver.ratePerMile)) return `${money(Number(driver.ratePerMile))} per mile · est. ${money(loadedMiles * Number(driver.ratePerMile))}`;
  if (driver.payType === "weekly" && Number(driver.weeklyRate)) return `${money(Number(driver.weeklyRate))} weekly rate`;
  if (driver.payType === "percentage" && Number(driver.payPercentage)) return `${Number(driver.payPercentage)}% of revenue · est. ${money(revenue * (Number(driver.payPercentage) / 100))}`;
  return "Driver pay not set";
}

function fileSize(bytes) {
  if (!bytes) return "0 KB";
  if (bytes < 1_000_000) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / 1_000_000).toFixed(1)} MB`;
}

function uploadedByLabel(uploadedBy) {
  if (!uploadedBy) return "Admin";
  return uploadedBy.roleLabel || uploadedBy.name || uploadedBy.email || "Admin";
}

function escapeAttribute(value) {
  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/"/g, "&quot;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function planPrice(plan) {
  if (plan.priceNote || plan.annualNote) {
    const notes = [plan.annualNote, plan.priceNote].filter(Boolean).join(" · ");
    return `$${plan.monthlyPrice}/month or $${number(plan.annualPrice)}/year · ${notes}`;
  }
  return `$${plan.monthlyPrice}/month or $${number(plan.annualPrice)}/year`;
}

function fleetSizeLabel(plan) {
  if (plan.minTrucks === plan.maxTrucks) return `${plan.minTrucks} truck`;
  return `${plan.minTrucks}-${plan.maxTrucks} trucks`;
}

function trialLabel(trial) {
  if (!trial) return "Trial not started";
  if (trial.status === "Active") return "Active";
  if (trial.status === "Expired") return "Trial expired";
  return `${trial.daysLeft} day${trial.daysLeft === 1 ? "" : "s"} left`;
}

function trialDetail(trial) {
  if (!trial) return "7-day trial";
  if (trial.status === "Active") return "Paid account";
  if (trial.status === "Expired") return trial.paymentAdded ? "Payment pending" : "Add payment to continue";
  return `Ends ${formatDate(String(trial.endsAt || "").slice(0, 10))}`;
}

function extractedSummary(item) {
  const data = item.extracted || {};
  const ai = item.aiScan || data.generic || {};
  const amount = displayDocumentAmount(item);
  if (item.type === "bol" && !data.loadNumber && !data.origin && !data.destination) {
    return "Delivery confirmation stored for bookkeeping";
  }
  const fields = [
    data.loadNumber ? `Load ${data.loadNumber}` : "",
    data.origin && data.destination ? `${data.origin} to ${data.destination}` : "",
    amount ? money(amount) : "",
    data.miles ? `${number(data.miles)} miles` : "",
    ai.dates?.length ? `${ai.dates.length} date${ai.dates.length === 1 ? "" : "s"} found` : ""
  ].filter(Boolean);
  if (!fields.length) return item.scanStatus || "Stored";
  return fields.join(" · ");
}

function scanDetail(item) {
  if (isCarrierPacketDocument(item)) return "Carrier packet document - no renewal date needed";
  const ai = item.aiScan || item.extracted?.generic || item.extracted || {};
  const generic = ai.generic || {};
  const candidateDates = ai.dateCandidates?.map((candidate) => candidate.date) || generic.dateCandidates?.map((candidate) => candidate.date) || [];
  const details = [
    ai.aiUsed === true || generic.aiUsed === true ? "Real AI used" : ai.aiUsed === false || generic.aiUsed === false ? "Local fallback used" : "",
    ai.aiError || generic.aiError ? `AI issue: ${(ai.aiError || generic.aiError).slice(0, 120)}` : "",
    ai.expirationDate ? `Expiration ${formatDate(ai.expirationDate)}` : generic.expirationDate ? `Expiration ${formatDate(generic.expirationDate)}` : "",
    displayDocumentAmount(item) ? `Amount ${money(displayDocumentAmount(item))}` : "",
    ai.loadNumber ? `Load ${ai.loadNumber}` : generic.loadNumber ? `Load ${generic.loadNumber}` : "",
    ai.dates?.length ? `Dates ${ai.dates.map(formatDate).join(", ")}` : generic.dates?.length ? `Dates ${generic.dates.map(formatDate).join(", ")}` : candidateDates.length ? `Date candidates ${candidateDates.map(formatDate).join(", ")}` : ""
  ].filter(Boolean);
  return details.length ? details.join(" · ") : "AI scan complete";
}

function documentEmailHref({ fileName, downloadPath, label = "Document" }) {
  const downloadUrl = `${location.origin}${downloadPath}`;
  const subject = encodeURIComponent(`${label}: ${fileName}`);
  const body = encodeURIComponent(`Hello,\n\nHere is the ${label.toLowerCase()} download link from RUNVARA:\n\n${downloadUrl}\n\nYou may need authorized RUNVARA access to open this private company document.\n\nThank you.`);
  return `mailto:?subject=${subject}&body=${body}`;
}

function loadDocumentEmailHref(item) {
  return documentEmailHref({
    fileName: item.fileName,
    downloadPath: `/api/documents/${item.id}`,
    label: documentLabel(item.type)
  });
}

function complianceDocumentEmailHref(item) {
  return documentEmailHref({
    fileName: item.fileName,
    downloadPath: `/api/compliance/${item.id}`,
    label: complianceLabel(item.type, item.fileName)
  });
}

function receiptEmailHref(item) {
  return documentEmailHref({
    fileName: item.sourceReceipt?.fileName || item.description || "Receipt",
    downloadPath: `/api/expenses/receipt/${item.id}`,
    label: "Receipt"
  });
}


function renderDocuments() {
  const documents = state.documents || [];
  const visibleDocuments = documents.filter((item) => {
    const haystack = Object.values(item).join(" ").toLowerCase();
    return haystack.includes(state.query.toLowerCase()) && matchesDateRange(item.uploadedAt);
  });
  const rateCons = visibleDocuments.filter((item) => item.type === "rateCon").length;
  const bols = visibleDocuments.filter((item) => item.type === "bol").length;
  content.innerHTML = `
    <div class="metric-grid">
      ${metric("Rate Cons", rateCons, "Uploaded confirmations", "file-text")}
      ${metric("BOLs", bols, "Bills of lading", "receipt")}
      ${metric("Total documents", visibleDocuments.length, "Stored on the server", "upload")}
      ${metric("Auto-populated", visibleDocuments.filter((item) => item.createdTripId).length, "Trips created from docs", "route")}
    </div>
    <section class="panel">
      <div class="panel-header">
        <h2>Upload Documents</h2>
        <span class="muted">AI scans every upload for dates, amounts, and load details</span>
      </div>
      <div class="panel-body">
        <form class="inline-form document-form" id="documentForm">
          <select name="type">
            <option value="rateCon">Rate Con</option>
            <option value="bol">BOL</option>
          </select>
          <div class="upload-choice">
            <label class="file-button">Upload file<input name="fileUpload" type="file" accept="image/*,.pdf" /></label>
            <label class="file-button">Take photo<input name="fileCamera" type="file" accept="image/*" capture="environment" /></label>
          </div>
          <button class="primary-button" type="submit">Upload</button>
        </form>
        ${state.accountMessage ? `<p class="form-message">${state.accountMessage}</p>` : ""}
      </div>
    </section>
    <section class="panel">
      <div class="panel-header">
        <h2>Document Library</h2>
        <div class="filters">
          <button class="primary-button" type="button" data-email-selected-documents>Email Selected</button>
          <input id="searchInput" type="search" value="${state.query}" placeholder="Search documents" />
          ${dateRangeSelect()}
        </div>
      </div>
      <table class="data-table document-table">
        <thead>
          <tr><th></th><th>Type</th><th>File</th><th>Amount</th><th>Scan</th><th>Uploaded By</th><th>Uploaded</th><th></th></tr>
        </thead>
        <tbody>
          ${visibleDocuments.map((item) => `
            <tr>
              <td data-label="Select"><input type="checkbox" data-document-select="${item.id}" aria-label="Select ${documentLabel(item.type)} ${item.fileName}" /></td>
              <td data-label="Type"><span class="status ${item.type === "bol" ? "Scheduled" : "Paid"}">${documentLabel(item.type)}</span></td>
              <td data-label="File" class="file-name-cell">
                <a class="document-name-link" href="/api/documents/${item.id}" target="_blank" rel="noopener">${item.fileName}</a>
                <form class="rename-file-form" data-rename-document="${item.id}">
                  <input name="fileName" value="${escapeAttribute(item.fileName)}" maxlength="120" required aria-label="File name" />
                  <button class="chip-button" type="submit">Save</button>
                </form>
                <span class="muted">${fileSize(item.size)} · ${item.mimeType}</span>
              </td>
              <td data-label="Amount"><strong>${item.type === "bol" ? "Not required" : displayDocumentAmount(item) ? money(displayDocumentAmount(item)) : "Needs review"}</strong></td>
              <td data-label="Scan"><strong>${item.scanStatus || "Stored"}</strong><br><span class="muted">${extractedSummary(item)}</span>${item.createdTripId ? `<br><button class="chip-button" type="button" data-open-trip="${item.createdTripId}">View trip</button>` : ""}</td>
              <td data-label="Uploaded By"><strong>${uploadedByLabel(item.uploadedBy)}</strong></td>
              <td data-label="Uploaded">${formatDate(item.uploadedAt.slice(0, 10))}</td>
              <td data-label="Actions">
                <div class="table-actions">
                  <a class="ghost-button" href="${loadDocumentEmailHref(item)}">Email</a>
                  <button class="icon-button" type="button" data-delete-document="${item.id}" title="Delete document" aria-label="Delete document"><span data-icon="trash"></span></button>
                </div>
              </td>
            </tr>
          `).join("") || `<tr><td colspan="8">No Rate Cons or BOLs match this date range.</td></tr>`}
        </tbody>
      </table>
    </section>
  `;
}

function alertTone(days) {
  if (days < 0) return "Overdue";
  if (days <= 15) return "Pending";
  return "Scheduled";
}

function alertLabel(days) {
  if (days < 0) return "Overdue";
  if (days <= 15) return "Due soon";
  return "Upcoming";
}

function renewalAlertItem(alert) {
  return `
    <article class="list-item">
      <div><strong>${alert.label}</strong><span>${formatDate(alert.date)} · ${Math.abs(alert.daysUntil)} day${Math.abs(alert.daysUntil) === 1 ? "" : "s"} ${alert.daysUntil < 0 ? "overdue" : "remaining"}</span></div>
      <div class="alert-actions">
        <span class="status ${alertTone(alert.daysUntil)}">${alertLabel(alert.daysUntil)}</span>
        <button class="chip-button" type="button" data-complete-alert="${alert.id}">Complete</button>
      </div>
    </article>
  `;
}

function renderCompliance() {
  const documents = state.complianceDocuments || [];
  const alerts = state.complianceAlerts || [];
  const scanner = state.scannerStatus;
  const scannerMessage = scanner?.aiConfigured
    ? `Using ${scanner.model}.`
    : scanner?.keyPresent
      ? `OPENAI_API_KEY is present, but it does not look valid. It should start with sk-. Current detected length: ${scanner.keyLength}.`
      : "The backend does not see OPENAI_API_KEY. Add it to the Railway app service Variables, then redeploy.";
  content.innerHTML = `
    <p class="muted build-marker">Clearinghouse renewal fix loaded: Sep 25</p>
    <div class="metric-grid">
      ${metric("Compliance files", documents.length, "Insurance, DOT, Clearinghouse MVR, UCR, 2290, IFTA License, IRP-Cab Card, W9, NOA", "shield")}
      ${metric("Renewal alerts", alerts.length, "Includes IFTA deadlines", "receipt")}
      ${metric("IFTA due dates", "Q1 Apr 30", "Q2 Jul 31 / Q3 Oct 31 / Q4 Jan 31", "bar-chart")}
      ${metric("Next due", alerts[0] ? formatDate(alerts[0].date) : "Clear", alerts[0]?.label || "No urgent renewals", "file-text")}
    </div>
    <section class="panel">
      <div class="panel-header">
        <h2>AI Scanner Status</h2>
        <span class="status ${scanner?.aiConfigured ? "Paid" : "Pending"}">${scanner?.aiConfigured ? "AI connected" : "AI not connected"}</span>
      </div>
      <div class="panel-body">
        <p class="muted">${scanner ? scannerMessage : "Checking scanner connection..."}</p>
      </div>
    </section>
    <section class="panel">
      <div class="panel-header">
        <h2>MCS-150 Biennial Update</h2>
        <span class="muted">No paperwork upload needed; enter the last filed date</span>
      </div>
      <div class="panel-body">
        <form class="inline-form document-form" id="mcs150Form">
          <input name="lastFiledDate" type="date" required />
          <span class="muted">Next due date will be calculated 24 months later.</span>
          <button class="primary-button" type="submit">Save Reminder</button>
        </form>
      </div>
    </section>
    <section class="panel">
      <div class="panel-header">
        <h2>Upload Compliance Documents</h2>
        <span class="muted">AI scans every upload for expiration dates and renewal clues</span>
      </div>
      <div class="panel-body">
        <form class="inline-form document-form" id="complianceForm">
          <select name="type">
            ${Object.entries(complianceTypes).map(([value, label]) => `<option value="${value}">${label}</option>`).join("")}
          </select>
          <div class="upload-choice">
            <label class="file-button">Upload file<input name="fileUpload" type="file" accept="image/*,.pdf" /></label>
            <label class="file-button">Take photo<input name="fileCamera" type="file" accept="image/*" capture="environment" /></label>
          </div>
          <button class="primary-button" type="submit">Upload</button>
        </form>
        ${state.accountMessage ? `<p class="form-message">${state.accountMessage}</p>` : ""}
      </div>
    </section>
    <div class="compliance-layout">
      <section class="panel">
        <div class="panel-header"><h2>Renewal Alerts</h2><span class="muted">45-day document window plus IFTA</span></div>
        <div class="panel-body">
          <div class="list">
            ${alerts.map(renewalAlertItem).join("") || `<p class="muted">No compliance alerts right now.</p>`}
          </div>
        </div>
      </section>
      <section class="panel">
        <div class="panel-header">
          <h2>Compliance Library</h2>
          <div class="table-actions">
            <button class="primary-button" type="button" data-share-compliance>Share Selected</button>
            <span class="muted">${documents.length} files</span>
          </div>
        </div>
        <table class="data-table document-table compliance-table">
          <thead><tr><th></th><th>Type</th><th>File</th><th>Renewal</th><th>Uploaded By</th><th></th></tr></thead>
          <tbody>
            ${documents.map((item) => `
              <tr>
                <td data-label="Select"><input type="checkbox" data-compliance-select="${item.id}" aria-label="Select ${complianceLabel(item.type, item.fileName)} ${item.fileName}" /></td>
                <td data-label="Type"><span class="status Paid">${complianceLabel(item.type, item.fileName)}</span></td>
                <td data-label="File" class="file-name-cell">
                  ${item.manualOnly
                    ? `<strong>${item.fileName}</strong>`
                    : `<a class="document-name-link" href="/api/compliance/${item.id}" target="_blank" rel="noopener">${item.fileName}</a>`}
                  <br><span class="muted">${item.manualOnly ? "Reminder only" : fileSize(item.size)}</span>
                </td>
                <td data-label="Renewal">
                  <strong>${isCarrierPacketDocument(item) ? "No renewal needed" : item.expirationDate ? formatDate(item.expirationDate) : "Not detected"}</strong>
                  ${item.extracted?.completedDate ? `<br><span class="muted">Completed date: ${formatDate(item.extracted.completedDate)}</span>` : ""}
                  ${item.extracted?.aiError || item.aiScan?.aiError ? `<br><span class="muted">Scanner issue: ${(item.extracted?.aiError || item.aiScan?.aiError).slice(0, 90)}</span>` : ""}
                  ${item.expirationDate || isCarrierPacketDocument(item) ? "" : `
                    <form class="mini-date-form" data-expiration-form="${item.id}">
                      <label>${item.type === "clearinghouseMvr" ? "Completed date" : "Expiration date"}<input type="${item.type === "clearinghouseMvr" ? "text" : "date"}" name="expirationDate" ${item.type === "clearinghouseMvr" ? 'inputmode="numeric" placeholder="1/20/2025"' : ""} required /></label>
                      <button class="chip-button" type="submit">Save</button>
                      ${item.type === "clearinghouseMvr" ? '<span class="muted clearinghouse-renewal-preview" data-clearinghouse-renewal-preview></span>' : ""}
                    </form>
                  `}
                </td>
                <td data-label="Uploaded By"><strong>${uploadedByLabel(item.uploadedBy)}</strong></td>
                <td data-label="Actions">
                  <div class="table-actions">
                    ${item.manualOnly ? "" : `<a class="ghost-button" href="${complianceDocumentEmailHref(item)}">Email</a>`}
                    ${item.manualOnly || isCarrierPacketDocument(item) ? "" : `<button class="icon-button" type="button" data-rescan-compliance="${item.id}" title="Scan again" aria-label="Scan again"><span data-icon="refresh-cw"></span></button>`}
                    <button class="icon-button" type="button" data-delete-compliance="${item.id}" title="Delete compliance document" aria-label="Delete compliance document"><span data-icon="trash"></span></button>
                  </div>
                </td>
              </tr>
            `).join("") || `<tr><td colspan="6">No compliance documents uploaded yet.</td></tr>`}
          </tbody>
        </table>
      </section>
    </div>
  `;
}

function renderAffiliate() {
  const stats = state.customer?.affiliateStats || { referrals: [], earnedTotal: 0, pendingCount: 0, paidCount: 0 };
  const referralLink = `${location.origin}/?ref=${state.customer?.affiliateCode || ""}`;
  content.innerHTML = `
    <div class="metric-grid">
      ${metric("Reward", stats.rewardLabel || "One free month", "For fleets with 1-20 trucks", "receipt")}
      ${metric("Customer Discount", stats.discountLabel || "10% off the first 3 months", "Applied to referred customers", "bar-chart")}
      ${metric("Pending Rewards", stats.pendingRewardCount || 0, stats.eligibilityLabel || "Paid after 60 active days", "users")}
      ${metric("Referral code", state.customer?.affiliateCode || "None", "Unique to this customer", "share")}
    </div>
    <section class="panel">
      <div class="panel-header"><h2>Referral Program</h2><span class="muted">For fleets with 1-20 trucks</span></div>
      <div class="panel-body">
        <div class="package-grid">
          <article class="package-option active"><strong>Referrer</strong><span>One free month</span><em>Earned after 60 active days</em></article>
          <article class="package-option active"><strong>New customer</strong><span>10% discount</span><em>First three months</em></article>
          <article class="package-option active"><strong>Fleet size</strong><span>1-20 trucks</span><em>Owner-Operator, Small Fleet, Growth, or Growth Plus</em></article>
        </div>
      </div>
    </section>
    <section class="panel">
      <div class="panel-header"><h2>Referral Link</h2><span class="muted">One free month after 60 active days</span></div>
      <div class="panel-body">
        <div class="copy-row">
          <input value="${referralLink}" readonly aria-label="Affiliate referral link" />
          <button class="primary-button" type="button" data-copy-referral="${referralLink}">Copy Link</button>
        </div>
        <p class="muted">When a fleet with 1-20 trucks signs up with this link, they receive 10% off the first three months. This account receives one free month after the new customer remains active for at least 60 days.</p>
      </div>
    </section>
    <section class="panel">
      <div class="panel-header"><h2>Referral Activity</h2><span class="muted">${stats.referrals?.length || 0} referrals</span></div>
      <table class="data-table">
        <thead><tr><th>Customer</th><th>Email</th><th>Reward</th><th>Eligibility</th><th>Status</th></tr></thead>
        <tbody>
          ${(stats.referrals || []).map((item) => `
            <tr>
              <td><strong>${item.referredBusinessName}</strong></td>
              <td>${item.referredEmail}</td>
              <td>${item.rewardLabel || (item.rewardType === "free_month" ? "One free month" : item.commissionType === "signup_bonus_30_day" ? "Signup bonus" : item.commissionType === "recurring_12_months" ? "Legacy recurring" : "Referral")}</td>
              <td>${item.requiredActiveDays ? `${item.requiredActiveDays} active days` : item.eligibleAt ? "Eligibility pending" : "Pending activation"}</td>
              <td><span class="status ${item.status === "earned" ? "Paid" : "Pending"}">${item.status === "reward_pending_60_days" ? "60-day pending" : item.status === "earned" ? "Earned" : item.status === "active_recurring" ? "Legacy active" : "Pending"}</span></td>
            </tr>
          `).join("") || `<tr><td colspan="5">No referrals yet.</td></tr>`}
        </tbody>
      </table>
    </section>
  `;
}

function renderMultiCompanyWorkspace() {
  content.innerHTML = `
    <div class="metric-grid">
      ${metric("Workspace model", "Management layer", "Each carrier keeps its own subscription", "users")}
      ${metric("Approval required", "Owner authorized", "No company can be added without approval", "shield")}
      ${metric("Company switching", "One login", "Toggle between approved subscriber accounts", "share")}
      ${metric("Access control", "Suspends automatically", "Inactive company subscriptions pause workspace access", "credit-card")}
    </div>
    <section class="panel">
      <div class="panel-header">
        <h2>RUNVARA Multi-Company Workspace</h2>
        <span class="muted">For accountants, dispatchers, consultants, and management teams</span>
      </div>
      <div class="panel-body">
        <p class="muted">Manage all of your RUNVARA client accounts from one secure dashboard. Each trucking company maintains its own RUNVARA subscription, data, users, truck limits, billing, and reports.</p>
        <p class="muted">Accountants, dispatchers, consultants, and management teams can see this workspace option after they gain authorized account access. They can only link a company after the owner approves it.</p>
        <div class="package-grid">
          ${multiCompanyWorkspacePlans.map((plan) => `
            <button class="package-option ${state.selectedWorkspacePlan === plan.id ? "active" : ""}" type="button" data-workspace-plan="${plan.id}">
              <strong>${plan.name}</strong>
              <span>${plan.companies} linked companies</span>
              <em>${plan.price}</em>
            </button>
          `).join("")}
        </div>
      </div>
    </section>
    <div class="dashboard-grid">
      <section class="panel">
        <div class="panel-header"><h2>Add Authorized Company</h2><span class="muted">Requires owner approval</span></div>
        <div class="panel-body">
          <form class="inline-form">
            <input type="text" placeholder="Business name" aria-label="Business name" />
            <input type="text" placeholder="DOT number" aria-label="DOT number" />
            <input type="email" placeholder="Owner email" aria-label="Owner email" />
            <button class="primary-button" type="button">Request Access</button>
          </form>
          <div class="insight-list">
            <article class="insight-item"><strong>1. Carrier subscribes first</strong><span>The trucking company keeps its own active RUNVARA plan.</span></article>
            <article class="insight-item"><strong>2. Owner authorizes access</strong><span>The owner invites or approves the professional workspace user.</span></article>
            <article class="insight-item"><strong>3. Workspace links account</strong><span>The professional can switch into that company after approval.</span></article>
          </div>
        </div>
      </section>
      <section class="panel">
        <div class="panel-header"><h2>Linked Companies</h2><span class="muted">Example workspace toggle</span></div>
        <div class="panel-body">
          <div class="list account-list">
            ${sampleWorkspaceCompanies.map((company, index) => `
              <article class="list-item">
                <div>
                  <strong>${company.name}</strong>
                  <span>${company.dot} · ${company.plan} · ${company.trucks} truck${company.trucks === 1 ? "" : "s"}</span>
                </div>
                <div class="table-actions">
                  <span class="status ${company.status === "Authorized" ? "Paid" : "Pending"}">${company.status}</span>
                  <button class="chip-button" type="button" ${company.status !== "Authorized" ? "disabled" : ""}>${index === 0 ? "Current" : "Switch"}</button>
                </div>
              </article>
            `).join("")}
          </div>
        </div>
      </section>
    </div>
    <section class="panel">
      <div class="panel-header"><h2>Data Separation Rules</h2><span class="muted">Workspace access is not shared billing</span></div>
      <div class="panel-body">
        <div class="package-grid">
          <article class="package-option active"><strong>Carrier billing</strong><span>Separate subscription</span><em>Each company pays for its own trucks and users</em></article>
          <article class="package-option active"><strong>Workspace fee</strong><span>Separate management fee</span><em>Professional pays for multi-company convenience</em></article>
          <article class="package-option active"><strong>Inactive carrier</strong><span>Access suspended</span><em>Workspace cannot view that company until active again</em></article>
        </div>
      </div>
    </section>
  `;
}

function renderAccount() {
  const customer = state.customer;
  const plan = customer.subscription || subscriptionPlans[customer.subscriptionTier] || subscriptionPlans.silver;
  const trucks = customer.trucks || [];
  const drivers = customer.drivers || [];
  const driverCount = drivers.filter((driver) => (driver.role || "driver") === "driver").length;
  const staffCount = drivers.length - driverCount;
  const trial = customer.trial;
  content.innerHTML = `
    <div class="metric-grid">
      ${metric("Subscription", plan.name, planPrice(plan), "users")}
      ${metric("Trial", trialLabel(trial), trialDetail(trial), "credit-card")}
      ${metric("Truck slots", `${trucks.length}/${plan.maxTrucks}`, `${Math.max(plan.maxTrucks - trucks.length, 0)} slots available`, "route")}
      ${metric("Driver access", `${driverCount}/${plan.maxTrucks}`, "Package driver seats", "file-text")}
      ${metric("Office access", staffCount, "Bookkeeper/accountant and dispatcher", "users")}
      ${metric("Admin", customer.email, customer.businessName, "receipt")}
    </div>
    <section class="panel">
      <div class="panel-header">
        <h2>Subscription Packages</h2>
        <span class="muted">Choose the fleet size for this account</span>
      </div>
      <div class="panel-body">
        <div class="package-grid">
          ${Object.values(subscriptionPlans).map((item) => `
            <button class="package-option ${item.id === plan.id ? "active" : ""}" type="button" data-plan="${item.id}">
              <strong>${item.name}</strong>
              <span>${fleetSizeLabel(item)}</span>
              <em>${planPrice(item)}</em>
            </button>
          `).join("")}
        </div>
        ${state.accountMessage ? `<p class="form-message">${state.accountMessage}</p>` : ""}
      </div>
    </section>
    <section class="panel">
      <div class="panel-header">
        <h2>Multi-Company Workspace Plans</h2>
        <span class="muted">Add-on for managing multiple active RUNVARA subscribers</span>
      </div>
      <div class="panel-body">
        <p class="muted">Each trucking company keeps its own RUNVARA subscription. These workspace plans are an additional management layer for accountants, dispatchers, consultants, and management teams.</p>
        <div class="package-grid">
          ${multiCompanyWorkspacePlans.map((workspacePlan) => `
            <button class="package-option ${state.selectedWorkspacePlan === workspacePlan.id ? "active" : ""}" type="button" data-workspace-plan="${workspacePlan.id}">
              <strong>${workspacePlan.name}</strong>
              <span>${workspacePlan.companies} linked subscriber companies</span>
              <em>${workspacePlan.price}</em>
            </button>
          `).join("")}
        </div>
      </div>
    </section>
    <section class="panel">
      <div class="panel-header"><h2>Billing Status</h2><span class="muted">Used for referral reward eligibility</span></div>
      <div class="panel-body">
        <div class="list-item">
          <div>
            <strong>Trial and first month payment</strong>
            <span>${trialLabel(trial)} · ${customer.firstMonthPaid ? "First month marked paid" : "First month not marked paid yet"}</span>
          </div>
          <button class="primary-button" type="button" data-mark-first-paid ${customer.firstMonthPaid ? "disabled" : ""}>Mark First Month Paid</button>
        </div>
        ${customer.referralDiscount ? `
          <div class="list-item">
            <div>
              <strong>Referral discount</strong>
              <span>${customer.referralDiscount.percent}% off the first ${customer.referralDiscount.monthsTotal} months · ${customer.referralDiscount.monthsRemaining} months remaining</span>
            </div>
          </div>
        ` : ""}
      </div>
    </section>
    <div class="dashboard-grid">
      <section class="panel">
        <div class="panel-header"><h2>Truck Slots</h2><span class="muted">${trucks.length} of ${plan.maxTrucks} used</span></div>
        <div class="panel-body">
          <form class="inline-form" id="truckForm">
            <input name="unitNumber" type="text" required placeholder="Truck or unit number" />
            <input name="vin" type="text" placeholder="VIN optional" />
            <button class="primary-button" type="submit">Add Truck</button>
          </form>
          <div class="list account-list">
            ${trucks.map((truck) => `
              <article class="list-item">
                <div><strong>${truck.unitNumber}</strong><span>${truck.vin || "No VIN entered"} · ${truck.status}</span></div>
                <button class="icon-button" type="button" data-delete-truck="${truck.id}" title="Remove truck" aria-label="Remove truck"><span data-icon="trash"></span></button>
              </article>
            `).join("") || `<p class="muted">No trucks added yet.</p>`}
          </div>
        </div>
      </section>
      <section class="panel account-access-panel">
        <div class="panel-header"><h2>Account Access</h2><span class="muted">Invite dispatch, accounting, payroll, compliance, drivers, and read-only users</span></div>
        <div class="panel-body">
          <form class="inline-form driver-form" id="driverForm">
            <input name="name" type="text" required placeholder="User name" />
            <input name="email" type="email" required placeholder="user@example.com" />
            <select name="role" data-permission-role>
              ${Object.entries(accountAccessRoles).map(([value, label]) => `<option value="${value}">${label}</option>`).join("")}
            </select>
            <input name="truckNumber" type="text" placeholder="Truck/unit number" />
            <select name="payType">
              <option value="">Driver pay type</option>
              <option value="per_mile">Rate per mile</option>
              <option value="weekly">Set weekly rate</option>
              <option value="percentage">Percentage of load</option>
            </select>
            <input name="ratePerMile" type="number" min="0" step="0.01" placeholder="Rate per mile" />
            <input name="weeklyRate" type="number" min="0" step="0.01" placeholder="Weekly rate" />
            <input name="payPercentage" type="number" min="0" max="100" step="0.01" placeholder="Pay percentage" />
            <label class="compact-field">Invite expires<input name="inviteExpiresAt" type="date" value="${defaultInviteExpirationDate()}" required /></label>
            ${renderPermissionEditor("driver")}
            <button class="primary-button" type="submit">Send Access</button>
          </form>
          ${renderAccountAccessTable(drivers, trucks)}
          <div class="list account-list hidden">
            ${drivers.map((driver) => {
              const assignedTruck = trucks.find((truck) => truck.id === driver.truckId);
              const absoluteLink = `${location.origin}${driver.inviteLink}`;
              const role = driver.role || "driver";
              return `
                <article class="list-item driver-item">
                  <div>
                    <strong>${driver.name}</strong>
                    <span>${accountRoleLabel(role)}${role === "driver" ? ` · ${assignedTruck ? assignedTruck.unitNumber : "No truck assigned"}` : ""}</span>
                    ${role === "driver" ? `<span>${driverPayLabel(driver)}</span>` : ""}
                    <span>${permissionLabelList(driver.permissions || permissionsForInviteRole(role))}</span>
                    <span>Expires ${driver.inviteExpiresAt ? new Date(driver.inviteExpiresAt).toLocaleDateString() : "not set"}${driver.inviteUsedAt ? ` · Accepted ${new Date(driver.inviteUsedAt).toLocaleDateString()}` : ""}</span>
                    <span>${driver.email}</span>
                    ${driver.inviteLink ? `<a href="mailto:${driver.email}?subject=Your RUNVARA access&body=${encodeURIComponent(`Use this secure one-time link to verify your email and set your RUNVARA password: ${absoluteLink}`)}">Open email</a>` : ""}
                  </div>
                  <div>
                    <span class="status Scheduled">${driver.status}</span>
                    ${driver.inviteLink ? `<button class="chip-button" type="button" data-resend-driver="${driver.id}">Resend</button><button class="chip-button" type="button" data-cancel-driver="${driver.id}">Cancel</button>` : ""}
                    <button class="icon-button" type="button" data-delete-driver="${driver.id}" title="Remove driver access" aria-label="Remove driver access"><span data-icon="trash"></span></button>
                  </div>
                </article>
              `;
            }).join("") || `<p class="muted">No account access has been sent yet.</p>`}
          </div>
        </div>
      </section>
    </div>
  `;
}

function renderPaymentAccount() {
  const customer = state.customer;
  const plan = customer.subscription || subscriptionPlans[customer.subscriptionTier] || subscriptionPlans.silver;
  const payment = customer.paymentInfo || {};
  const trial = customer.trial;
  const integrations = customer.integrations || {};
  const paymentPolicy = customer.paymentPolicy || {};
  const paymentStatus = payment.providerStatus || integrations.stripe || "Stripe not connected";
  const stripeConnected = String(integrations.stripe || "").startsWith("Connected");
  const checkoutEnabled = stripeConnected && paymentPolicy.checkoutEnabled !== false;
  const checkoutLabelPrefix = paymentPolicy.testCheckoutLabel ? "Test " : "Pay ";
  const plaidReady = integrations.plaid === "Connected";
  const bank = payment.bankConnection;
  const mfa = customer.mfa || {};
  content.innerHTML = `
    <div class="metric-grid">
      ${metric("Plan", plan.name, planPrice(plan), "credit-card")}
      ${metric("Trial", trialLabel(trial), trialDetail(trial), "credit-card")}
      ${metric("Stripe", integrations.stripe || "Not connected", "Use Stripe for cards and subscriptions", "credit-card")}
      ${metric("Plaid", integrations.plaid || "Not connected", "Use Plaid for bank connection", "shield")}
      ${metric("Billing Email", payment.billingEmail || customer.email, "Receipts and account notices", "file-text")}
    </div>
    <section class="panel">
      <div class="panel-header">
        <h2>Billing Setup</h2>
        <span class="muted">Only account admins can update billing contact details</span>
      </div>
      <div class="panel-body">
        <div class="security-banner">
          <strong>${paymentStatus}</strong>
          <span>For security, customers should enter card details only through Stripe Checkout after Stripe is connected. RUNVARA will not store full card numbers or CVV codes.</span>
        </div>
        <div class="security-banner ${paymentPolicy.testCheckoutLabel ? "warning-banner" : ""}">
          <strong>${paymentPolicy.complimentaryBetaAccess ? "Complimentary beta access" : paymentPolicy.testCheckoutLabel ? "Stripe test checkout only" : "Payment processing"}</strong>
          <span>${paymentPolicy.message || "Use Stripe Checkout for subscription payments."}</span>
        </div>
        <form class="billing-form" id="paymentForm">
          <label>
            Billing name
            <input name="billingName" type="text" required value="${payment.billingName || customer.businessName || ""}" placeholder="Name on card" />
          </label>
          <label>
            Billing email
            <input name="billingEmail" type="email" required value="${payment.billingEmail || customer.email || ""}" placeholder="billing@example.com" />
          </label>
          <div class="billing-actions">
            <button class="primary-button" type="submit">Save Billing Contact</button>
            <button class="primary-button" type="button" data-stripe-checkout="month" ${checkoutEnabled ? "" : "disabled"}>${checkoutLabelPrefix}Monthly with Stripe</button>
            <button class="ghost-button" type="button" data-stripe-checkout="year" ${checkoutEnabled ? "" : "disabled"}>${checkoutLabelPrefix}Annual with Stripe</button>
            <a class="chip-button" href="/terms" target="_blank" rel="noreferrer">Terms</a>
            <a class="chip-button" href="/privacy" target="_blank" rel="noreferrer">Privacy</a>
            <a class="chip-button" href="/beta-agreement" target="_blank" rel="noreferrer">Beta Agreement</a>
          </div>
        </form>
        ${state.accountMessage ? `<p class="form-message">${state.accountMessage}</p>` : ""}
      </div>
    </section>
    <section class="panel">
      <div class="panel-header">
        <h2>Multi-Factor Authentication</h2>
        <span class="muted">${mfa.required ? "Required for this account" : "Optional"}</span>
      </div>
      <div class="panel-body">
        <div class="security-banner">
          <strong>${mfa.enabled ? "MFA enabled" : "MFA setup needed"}</strong>
          <span>Use an authenticator app first. Email codes are a temporary fallback. Save recovery codes somewhere secure.</span>
        </div>
        <div class="billing-actions">
          <button class="primary-button" type="button" data-mfa-setup>${mfa.authenticatorEnabled ? "Regenerate Authenticator Setup" : "Set Up Authenticator App"}</button>
        </div>
        ${state.mfaSetup ? `
          <form class="billing-form" id="mfaEnableForm">
            <label>Authenticator secret<input readonly value="${state.mfaSetup.secret}" /></label>
            <label>Authenticator code<input name="code" inputmode="numeric" autocomplete="one-time-code" placeholder="6-digit code" required /></label>
            <button class="primary-button" type="submit">Enable MFA</button>
          </form>
        ` : ""}
        ${mfa.recoveryCodesRemaining ? `<p class="muted">${mfa.recoveryCodesRemaining} recovery codes remaining.</p>` : ""}
        ${state.accountMessage ? `<p class="form-message">${state.accountMessage}</p>` : ""}
      </div>
    </section>
    <section class="panel">
      <div class="panel-header">
        <h2>Bank Connection</h2>
        <span class="muted">Connect securely with Plaid</span>
      </div>
      <div class="panel-body">
        <div class="security-banner">
          <strong>${bank?.status || integrations.plaid || "Plaid not connected"}</strong>
          <span>${bank ? `${bank.institutionName || "Bank"} connected${bank.accountMasks?.length ? ` · ending ${bank.accountMasks.join(", ")}` : ""}` : "Users connect their bank through Plaid Link. RUNVARA never asks for or saves bank usernames or passwords."}</span>
        </div>
        <div class="billing-actions">
          <button class="primary-button" type="button" data-plaid-link ${plaidReady ? "" : "disabled"}>${bank ? "Reconnect Bank" : "Connect Bank Account"}</button>
        </div>
      </div>
    </section>
  `;
}

function renderSupport() {
  const supportGrants = state.customer?.supportAccessGrants || [];
  const activeSupport = state.customer?.activeSupportAccess || supportGrants.find((grant) => grant.status === "Approved" && grant.expiresAt && new Date(grant.expiresAt) > new Date());
  const canManageSupportAccess = !isDriverAccount() && hasPermission("manageCompanyUsers");
  const supportAccessPanel = canManageSupportAccess ? `
    <section class="panel">
      <div class="panel-header">
        <h2>Support Access</h2>
        <span class="muted">Customer-controlled account review</span>
      </div>
      <div class="panel-body">
        <div class="security-banner">
          <strong>${activeSupport ? "Support access approved" : "No active support access"}</strong>
          <span>${activeSupport ? `Expires ${formatDate(activeSupport.expiresAt)}. Sensitive financial and payroll data ${activeSupport.restrictSensitiveData ? "remain restricted" : "are included for this support window"}.` : "RUNVARA support can only review account details after you approve a limited access window."}</span>
        </div>
        <div class="list">
          ${supportGrants.slice(0, 5).map((grant) => `
            <article class="list-item">
              <div>
                <strong>${escapeHtml(grant.status || "Approved")}</strong>
                <span>${escapeHtml(grant.reason || "Support access")} · expires ${formatDate(grant.expiresAt)}</span>
                <span>${grant.restrictSensitiveData ? "Financial and payroll data restricted" : "Financial access included"}</span>
              </div>
              ${grant.status === "Approved" && grant.expiresAt && new Date(grant.expiresAt) > new Date() ? `<button class="ghost-button" type="button" data-revoke-support-access="${escapeHtml(grant.id)}">Revoke</button>` : ""}
            </article>
          `).join("") || `<p class="muted">No support access has been approved.</p>`}
        </div>
      </div>
    </section>
  ` : "";
  content.innerHTML = `
    <section class="panel">
      <div class="panel-header">
        <h2>Feedback and Bug Reports</h2>
        <div class="billing-actions">
          <a class="ghost-button" href="/beta-launch" target="_blank" rel="noreferrer">Beta Launch Checklist</a>
          <a class="ghost-button" href="mailto:info@thetruckerconsultant.com?subject=RUNVARA Support Request">Contact Us</a>
        </div>
      </div>
      <div class="panel-body">
        <form class="support-form" id="supportIssueForm">
          <label>
            Issue area
            <select name="category" required>
              <option value="AI Scanner">AI Scanner</option>
              <option value="Login or Access">Login or Access</option>
              <option value="Billing or Subscription">Billing or Subscription</option>
              <option value="Compliance Documents">Compliance Documents</option>
              <option value="Rate Cons/BOLs">Rate Cons/BOLs</option>
              <option value="Expenses">Expenses</option>
              <option value="Other">Other</option>
            </select>
          </label>
          <label>
            Subject
            <input name="subject" type="text" required maxlength="120" placeholder="Short description" />
          </label>
          <label class="support-message-field">
            What happened?
            <textarea name="message" required rows="7" placeholder="Describe the issue so support can review it."></textarea>
          </label>
          ${canManageSupportAccess ? `
            <label class="checkbox-row">
              <input name="requestSupportAccess" type="checkbox" />
              Approve temporary support access for this issue
            </label>
            <label>
              Access window
              <select name="supportAccessDurationHours">
                <option value="24">24 hours</option>
                <option value="8">8 hours</option>
                <option value="48">48 hours</option>
                <option value="72">72 hours</option>
              </select>
            </label>
            <label class="checkbox-row">
              <input name="restrictSensitiveData" type="checkbox" checked />
              Keep sensitive financial and payroll data restricted
            </label>
          ` : ""}
          <div class="billing-actions">
            <button class="primary-button" type="submit">Send Issue</button>
            <a class="chip-button" href="mailto:info@thetruckerconsultant.com">Email Support</a>
          </div>
        </form>
        ${state.accountMessage ? `<p class="form-message">${state.accountMessage}</p>` : ""}
      </div>
    </section>
    ${supportAccessPanel}
  `;
}

function isDriverAccount() {
  return state.customer?.role === "driver";
}

function renderDriverMobile() {
  const profile = state.customer?.driverProfile || {};
  const loads = state.records.trips || [];
  const expenses = state.records.expenses || [];
  const settlements = state.records.settlements || [];
  const docs = state.documents || [];
  const alerts = state.complianceAlerts || [];
  content.innerHTML = `
    <div class="driver-mobile">
      <section class="panel">
        <div class="panel-header"><h2>My Loads</h2><span class="muted">${loads.length} assigned</span></div>
        <div class="panel-body">
          <div class="list">
            ${loads.map((load) => `
              <article class="list-item">
                <div>
                  <strong>${load.description || "Assigned load"}</strong>
                  <span>${load.origin || "Pickup TBD"} to ${load.destination || "Delivery TBD"}</span>
                  <span>${formatDate(load.date)} · ${load.status || "Scheduled"} · ${number(load.miles || 0)} miles</span>
                </div>
              </article>
            `).join("") || `<p class="muted">No assigned loads are available yet.</p>`}
          </div>
        </div>
      </section>
      <section class="panel">
        <div class="panel-header"><h2>Upload Documents</h2><span class="muted">BOLs, PODs, receipts, and load files</span></div>
        <div class="panel-body driver-actions">
          <form class="inline-form document-form" id="documentForm">
            <select name="type">
              <option value="bol">BOL / POD</option>
              <option value="rateCon">Other load document</option>
            </select>
            <input name="file" type="file" accept=".pdf,.png,.jpg,.jpeg,.txt" required />
            <button class="primary-button" type="submit">Upload</button>
          </form>
          <form class="inline-form document-form" id="receiptForm">
            <select name="category">
              <option value="">Receipt category</option>
              <option value="Fuel">Fuel</option>
              <option value="Meals">Meals</option>
              <option value="Road costs">Road costs</option>
              <option value="Maintenance">Maintenance</option>
              <option value="General">General</option>
            </select>
            <input name="file" type="file" accept=".pdf,.png,.jpg,.jpeg,.txt" required />
            <button class="primary-button" type="submit">Submit Expense</button>
          </form>
          ${state.accountMessage ? `<p class="form-message">${state.accountMessage}</p>` : ""}
        </div>
      </section>
      <section class="panel">
        <div class="panel-header"><h2>Report Detention or Delay</h2></div>
        <div class="panel-body">
          <form class="support-form" id="driverDelayForm">
            <label>Type<select name="type"><option>Delay</option><option>Detention</option></select></label>
            <label>Load<select name="loadId"><option value="">Select load</option>${loads.map((load) => `<option value="${load.id}">${load.description || load.id}</option>`).join("")}</select></label>
            <label>Location<input name="location" type="text" placeholder="City, state or facility" /></label>
            <label class="support-message-field">Notes<textarea name="notes" rows="4" placeholder="What happened?"></textarea></label>
            <button class="primary-button" type="submit">Submit Report</button>
          </form>
        </div>
      </section>
      <section class="panel">
        <div class="panel-header"><h2>Settlements</h2><span class="muted">Your statement only</span></div>
        <div class="panel-body">
          <div class="list">
            ${settlements.map((item) => `<article class="list-item"><div><strong>${item.driverName}</strong><span>${driverPayLabel(item)}</span><span>${item.status}</span></div></article>`).join("") || `<p class="muted">No settlement statement is available yet.</p>`}
          </div>
        </div>
      </section>
      <section class="panel">
        <div class="panel-header"><h2>My Compliance</h2></div>
        <div class="panel-body">
          <div class="list">
            ${alerts.map(renewalAlertItem).join("") || `<p class="muted">No compliance expirations need attention right now.</p>`}
          </div>
        </div>
      </section>
      <section class="panel">
        <div class="panel-header"><h2>My Profile</h2><span class="muted">${profile.truckNumber || "No truck assigned"}</span></div>
        <div class="panel-body">
          <form class="inline-form" id="driverProfileForm">
            <input name="phone" type="tel" value="${escapeAttribute(profile.phone || "")}" placeholder="Phone" />
            <input name="emergencyContact" type="text" value="${escapeAttribute(profile.emergencyContact || "")}" placeholder="Emergency contact" />
            <button class="primary-button" type="submit">Update</button>
          </form>
        </div>
      </section>
    </div>
  `;
}

function renderContent() {
  if (isDriverAccount()) {
    sectionTitle.textContent = "Driver Account";
    sectionEyebrow.textContent = "Assigned loads, documents, expenses, and settlements";
    renderDriverMobile();
    renderIcons(content);
    return;
  }
  if (state.view === "dashboard") renderDashboard();
  if (state.view === "trips") renderTableView("trips", "Trip Ledger", [
    { label: "Date", render: (item) => formatDate(item.date) },
    { label: "Load", render: (item) => `<strong>${item.description}</strong><br><span class="muted">${item.origin} to ${item.destination}</span>` },
    { label: "Miles", render: (item) => number(item.miles) },
    { label: "Revenue", render: (item) => money(item.amount) },
    { label: "Status", render: (item) => `<span class="status ${item.status}">${item.status}</span>` }
  ]);
  if (state.view === "expenses") renderExpenses();
  if (state.view === "invoices") renderTableView("invoices", "Invoice Tracker", [
    { label: "Date", render: (item) => formatDate(item.date) },
    { label: "Invoice", render: (item) => `<strong>${item.description}</strong>` },
    { label: "Amount", render: (item) => money(item.amount) },
    { label: "Status", render: (item) => `<span class="status ${item.status}">${item.status}</span>` }
  ]);
  if (state.view === "maintenance") renderTableView("maintenance", "Maintenance Log", [
    { label: "Date", render: (item) => formatDate(item.date) },
    { label: "Service", render: (item) => `<strong>${item.description}</strong>` },
    { label: "Cost", render: (item) => money(item.amount) },
    { label: "Status", render: (item) => `<span class="status ${item.status}">${item.status}</span>` }
  ]);
  if (state.view === "rateCons") renderDocuments();
  if (state.view === "compliance") {
    if (!state.scannerStatus) loadScannerStatus().then(renderContent);
    renderCompliance();
  }
  if (state.view === "affiliate") renderAffiliate();
  if (state.view === "reports") renderReports();
  if (state.view === "userManagement") renderAccount();
  if (state.view === "account") renderPaymentAccount();
  if (state.view === "multiCompany") renderMultiCompanyWorkspace();
  if (state.view === "support") renderSupport();
  renderIcons(content);
  refreshClearinghouseRenewalPreviews();
}

function currentCollection() {
  if (["trips", "expenses", "invoices", "maintenance"].includes(state.view)) return state.view;
  return "trips";
}

async function startMfaSetup() {
  const payload = await api("/api/mfa/setup", { method: "POST" });
  state.mfaSetup = payload;
  state.accountMessage = `Add this secret to your authenticator app: ${payload.secret}`;
  renderContent();
}

async function enableMfa(event) {
  event.preventDefault();
  const formData = new FormData(event.target);
  const payload = await api("/api/mfa/enable", {
    method: "POST",
    body: JSON.stringify({ code: formData.get("code") })
  });
  state.customer = payload.customer;
  state.mfaSetup = null;
  state.accountMessage = `MFA enabled. Recovery codes: ${payload.recoveryCodes.join(", ")}`;
  renderContent();
}

function openEntryDialog(type = currentCollection().replace("s", "")) {
  entryForm.reset();
  entryForm.elements.date.valueAsDate = new Date();
  entryType.value = type;
  toggleTripFields();
  dialog.showModal();
}

function toggleTripFields() {
  document.querySelectorAll(".trip-only").forEach((field) => {
    field.style.display = entryType.value === "trip" ? "grid" : "none";
  });
}

async function addEntry(event) {
  event?.preventDefault();
  if (!entryForm.checkValidity()) {
    entryForm.reportValidity();
    return;
  }
  const data = Object.fromEntries(new FormData(entryForm).entries());
  const collection = data.type === "maintenance" ? "maintenance" : `${data.type}s`;
  const base = {
    date: data.date,
    description: data.description,
    amount: Number(data.amount),
    status: data.status
  };
  if (data.type === "trip") {
    Object.assign(base, { origin: data.origin || "Origin TBD", destination: data.destination || "Destination TBD", miles: Number(data.miles || 0) });
  }
  if (data.type === "expense") {
    base.category = "General";
  }
  const payload = await api(`/api/records/${collection}`, {
    method: "POST",
    body: JSON.stringify(base)
  });
  state.records = payload.records;
  dialog.close();
  setView(collection === "maintenance" ? "maintenance" : collection);
}

async function deleteEntry(id) {
  const collection = currentCollection();
  const payload = await api(`/api/records/${collection}/${id}`, { method: "DELETE" });
  state.records = payload.records;
  renderContent();
}

async function saveExpenseAmount(form) {
  try {
    const amount = Number(form.querySelector("input[name='amount']")?.value);
    if (!Number.isFinite(amount) || amount < 0) throw new Error("Enter a valid amount.");
    const payload = await api(`/api/records/expenses/${form.dataset.expenseAmountForm}`, {
      method: "PATCH",
      body: JSON.stringify({ amount })
    });
    state.records = payload.records;
    state.accountMessage = `Expense amount updated to ${money(amount)}.`;
    renderContent();
  } catch (error) {
    state.accountMessage = error.message;
    renderContent();
  }
}

function exportRecords() {
  window.location.href = "/api/export";
}

async function refreshAccount() {
  const payload = await api("/api/account");
  state.customer = payload.customer;
  customerName.textContent = payload.customer.businessName;
  customerFile.textContent = `${payload.customer.businessName} - 2026`;
  renderContent();
}

async function refreshAffiliate() {
  const payload = await api("/api/affiliate");
  state.customer = payload.customer;
  renderContent();
}

async function loadScannerStatus() {
  try {
    state.scannerStatus = await api("/api/scanner-status");
  } catch {
    state.scannerStatus = { aiConfigured: false, model: "unknown", fallbackAvailable: true };
  }
}

async function updatePlan(planId) {
  try {
    state.accountMessage = "";
    const payload = await api("/api/account/subscription", {
      method: "PATCH",
      body: JSON.stringify({ subscriptionTier: planId })
    });
    state.customer = payload.customer;
    state.accountMessage = `${payload.customer.subscription.name} is active.`;
    renderContent();
  } catch (error) {
    state.accountMessage = error.message;
    renderContent();
  }
}

async function markFirstMonthPaid() {
  try {
    const payload = await api("/api/billing/first-month-paid", { method: "POST" });
    state.customer = payload.customer;
    state.accountMessage = "First month marked paid. Any referral reward eligibility has been updated.";
    renderContent();
  } catch (error) {
    state.accountMessage = error.message;
    renderContent();
  }
}

async function updatePaymentInfo(form) {
  try {
    state.accountMessage = "";
    const formData = new FormData(form);
    const payload = await api("/api/account/payment", {
      method: "PATCH",
      body: JSON.stringify({
        billingName: formData.get("billingName"),
        billingEmail: formData.get("billingEmail")
      })
    });
    state.customer = payload.customer;
    state.accountMessage = "Billing contact saved. Stripe will handle card entry once connected.";
    renderContent();
  } catch (error) {
    state.accountMessage = error.message;
    renderContent();
  }
}

async function startStripeCheckout(interval) {
  try {
    state.accountMessage = "Opening Stripe Checkout...";
    renderContent();
    const payload = await api("/api/billing/stripe-checkout", {
      method: "POST",
      body: JSON.stringify({ interval })
    });
    window.location.href = payload.url;
  } catch (error) {
    state.accountMessage = error.message;
    renderContent();
  }
}

async function startPlaidLink() {
  try {
    if (!window.Plaid) throw new Error("Plaid Link did not load yet. Refresh the app and try again.");
    state.accountMessage = "Opening Plaid...";
    renderContent();
    const payload = await api("/api/plaid/link-token", { method: "POST" });
    const handler = window.Plaid.create({
      token: payload.linkToken,
      onSuccess: async (public_token, metadata) => {
        try {
          const exchange = await api("/api/plaid/exchange", {
            method: "POST",
            body: JSON.stringify({ public_token, metadata })
          });
          state.customer = exchange.customer;
          state.accountMessage = "Bank account connected with Plaid.";
          renderContent();
        } catch (error) {
          state.accountMessage = error.message;
          renderContent();
        }
      },
      onExit: (error) => {
        if (error) state.accountMessage = error.display_message || error.error_message || "Plaid connection was not completed.";
        else state.accountMessage = "Plaid connection was closed.";
        renderContent();
      }
    });
    handler.open();
  } catch (error) {
    state.accountMessage = error.message;
    renderContent();
  }
}

async function confirmStripeCheckoutFromUrl() {
  const params = new URLSearchParams(location.search);
  const sessionId = params.get("session_id");
  if (params.get("stripe") !== "success" || !sessionId) return;
  try {
    const payload = await api("/api/billing/stripe-confirm", {
      method: "POST",
      body: JSON.stringify({ sessionId })
    });
    state.customer = payload.customer;
    state.accountMessage = "Stripe payment connected. Subscription is active.";
    history.replaceState({}, "", location.pathname);
    setView("account");
  } catch (error) {
    state.accountMessage = error.message;
    history.replaceState({}, "", location.pathname);
    setView("account");
  }
}

async function submitSupportIssue(form) {
  try {
    state.accountMessage = "";
    const formData = new FormData(form);
    const payload = await api("/api/support/issues", {
      method: "POST",
      body: JSON.stringify({
        category: formData.get("category"),
        subject: formData.get("subject"),
        message: formData.get("message"),
        requestSupportAccess: formData.get("requestSupportAccess") === "on",
        supportAccessDurationHours: formData.get("supportAccessDurationHours"),
        restrictSensitiveData: formData.get("restrictSensitiveData") === "on"
      })
    });
    if (state.customer) state.customer.supportIssues = payload.supportIssues;
    if (payload.customer) state.customer = payload.customer;
    form.reset();
    state.accountMessage = payload.supportAccess
      ? "Issue sent. Temporary support access is approved and can be revoked here any time."
      : "Issue sent. Support can review the ticket without account access.";
    renderContent();
  } catch (error) {
    state.accountMessage = error.message;
    renderContent();
  }
}

async function revokeSupportAccess(id) {
  try {
    state.accountMessage = "";
    const payload = await api(`/api/support/access-grants/${id}/revoke`, { method: "POST" });
    if (payload.customer) state.customer = payload.customer;
    state.accountMessage = "Support access revoked.";
    renderContent();
  } catch (error) {
    state.accountMessage = error.message;
    renderContent();
  }
}

async function addTruck(form) {
  try {
    state.accountMessage = "";
    const formData = new FormData(form);
    const payload = await api("/api/trucks", {
      method: "POST",
      body: JSON.stringify({
        unitNumber: formData.get("unitNumber"),
        vin: formData.get("vin")
      })
    });
    state.customer = payload.customer;
    state.accountMessage = "Truck added.";
    renderContent();
  } catch (error) {
    state.accountMessage = error.message;
    renderContent();
  }
}

async function inviteDriver(form) {
  try {
    state.accountMessage = "";
    const formData = new FormData(form);
    const payload = await api("/api/drivers/invite", {
      method: "POST",
      body: JSON.stringify({
        name: formData.get("name"),
        email: formData.get("email"),
        role: formData.get("role"),
        permissions: formData.getAll("permissions"),
        inviteExpiresAt: formData.get("inviteExpiresAt"),
        truckNumber: formData.get("truckNumber"),
        payType: formData.get("payType"),
        ratePerMile: formData.get("ratePerMile"),
        weeklyRate: formData.get("weeklyRate"),
        payPercentage: formData.get("payPercentage")
      })
    });
    state.customer = payload.customer;
    state.accountMessage = "Account access created. Use the email button to send the invite.";
    renderContent();
  } catch (error) {
    state.accountMessage = error.message;
    renderContent();
  }
}

async function resendDriverInvite(id) {
  try {
    const payload = await api(`/api/drivers/${id}/resend`, { method: "POST" });
    state.customer = payload.customer;
    state.accountMessage = payload.inviteLink ? `Invite resent. Use the email button to send ${location.origin}${payload.inviteLink}` : "Invite resent.";
    renderContent();
  } catch (error) {
    state.accountMessage = error.message;
    renderContent();
  }
}

async function cancelDriverInvite(id) {
  try {
    const payload = await api(`/api/drivers/${id}/cancel`, { method: "POST" });
    state.customer = payload.customer;
    state.accountMessage = "Invitation cancelled.";
    renderContent();
  } catch (error) {
    state.accountMessage = error.message;
    renderContent();
  }
}

async function accountAccessAction(id, action, options = {}) {
  try {
    const payload = await api(`/api/drivers/${id}/${action}`, {
      method: options.method || "POST",
      body: options.body ? JSON.stringify(options.body) : undefined
    });
    if (payload.customer) state.customer = payload.customer;
    state.accountMessage = payload.inviteLink ? `Action complete. Send link: ${location.origin}${payload.inviteLink}` : "Account access updated.";
    renderContent();
  } catch (error) {
    state.accountMessage = error.message;
    renderContent();
  }
}

async function changeDriverRole(id) {
  const current = (state.customer?.drivers || []).find((driver) => driver.id === id);
  const role = window.prompt(`Enter role: ${Object.keys(accountAccessRoles).join(", ")}`, current?.role || "driver");
  if (!role) return;
  await accountAccessAction(id, "role", { method: "PATCH", body: { role, permissions: roleDefaultPermissions[role] || [] } });
}

async function showDriverHistory(id) {
  try {
    const payload = await api(`/api/drivers/${id}/history`);
    const lines = (payload.history || []).map((item) => `${new Date(item.createdAt).toLocaleString()} - ${item.action} by ${item.actorName}${item.details ? `: ${item.details}` : ""}`);
    state.accountMessage = lines.length ? lines.join(" | ") : "No access history recorded yet.";
    renderContent();
  } catch (error) {
    state.accountMessage = error.message;
    renderContent();
  }
}

function updateInvitePermissionEditor(select) {
  const form = select.closest("form");
  const editor = form?.querySelector("#permissionEditor");
  if (!form || !editor) return;
  editor.outerHTML = renderPermissionEditor(select.value);
}

function selectWorkspacePlan(planId) {
  const plan = multiCompanyWorkspacePlans.find((item) => item.id === planId);
  if (!plan) return;
  state.selectedWorkspacePlan = plan.id;
  state.accountMessage = `${plan.name} selected. Owner authorization is still required before linking any company.`;
  renderContent();
}

async function removeTruck(id) {
  const payload = await api(`/api/trucks/${id}`, { method: "DELETE" });
  state.customer = payload.customer;
  state.accountMessage = "Truck removed.";
  renderContent();
}

async function removeDriver(id) {
  const payload = await api(`/api/drivers/${id}`, { method: "DELETE" });
  state.customer = payload.customer;
  state.accountMessage = "Account access removed.";
  renderContent();
}

function readFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error("Could not read that file."));
    reader.readAsDataURL(file);
  });
}

function selectedUploadFile(formData) {
  return [formData.get("fileUpload"), formData.get("fileCamera"), formData.get("file")]
    .find((file) => file && file.name);
}

async function uploadDocument(form) {
  try {
    state.accountMessage = "";
    const formData = new FormData(form);
    const file = selectedUploadFile(formData);
    if (!file || !file.name) throw new Error("Choose a Rate Con or BOL file.");
    const data = await readFileAsDataUrl(file);
    const payload = await api("/api/documents", {
      method: "POST",
      body: JSON.stringify({
        type: formData.get("type"),
        fileName: file.name,
        mimeType: file.type || "application/octet-stream",
        data
      })
    });
    state.documents = payload.documents;
    if (payload.records) state.records = payload.records;
    if (state.customer) state.customer.documents = payload.documents;
    state.accountMessage = payload.document?.createdTripId ? "Document scanned and a trip was auto-populated." : "Document uploaded and scanned.";
    renderContent();
  } catch (error) {
    state.accountMessage = error.message;
    renderContent();
  }
}

async function uploadReceipt(form) {
  try {
    const formData = new FormData(form);
    const file = selectedUploadFile(formData);
    if (!file || !file.name) throw new Error("Choose a receipt image or PDF.");
    state.accountMessage = "Scanning receipt and creating expense...";
    renderContent();
    const data = await readFileAsDataUrl(file);
    const payload = await api("/api/expenses/receipt", {
      method: "POST",
      body: JSON.stringify({
        fileName: file.name,
        mimeType: file.type || "application/octet-stream",
        category: formData.get("category"),
        data
      })
    });
    state.records = payload.records;
    state.accountMessage = payload.expense?.amount
      ? `Receipt scanned. Expense added for ${money(payload.expense.amount)}.`
      : "Receipt scanned and expense added. Please review the amount.";
    renderContent();
  } catch (error) {
    state.accountMessage = error.message;
    renderContent();
  }
}

async function updateDriverProfile(form) {
  try {
    const formData = new FormData(form);
    const payload = await api("/api/driver/profile", {
      method: "PATCH",
      body: JSON.stringify({
        phone: formData.get("phone"),
        emergencyContact: formData.get("emergencyContact")
      })
    });
    state.customer = payload.customer;
    if (payload.records) state.records = payload.records;
    state.accountMessage = "Profile updated.";
    renderContent();
  } catch (error) {
    state.accountMessage = error.message;
    renderContent();
  }
}

async function reportDriverDelay(form) {
  try {
    const formData = new FormData(form);
    const payload = await api("/api/driver/detention-delay", {
      method: "POST",
      body: JSON.stringify({
        type: formData.get("type"),
        loadId: formData.get("loadId"),
        location: formData.get("location"),
        notes: formData.get("notes")
      })
    });
    if (payload.records) state.records = payload.records;
    state.accountMessage = "Report submitted.";
    renderContent();
  } catch (error) {
    state.accountMessage = error.message;
    renderContent();
  }
}

async function uploadComplianceDocument(form) {
  try {
    const formData = new FormData(form);
    const file = selectedUploadFile(formData);
    if (!file || !file.name) throw new Error("Choose a compliance document.");
    const documentType = formData.get("type");
    state.accountMessage = "Scanning document for expiration date...";
    renderContent();
    const data = await readFileAsDataUrl(file);
    const payload = await api("/api/compliance", {
      method: "POST",
      body: JSON.stringify({
        type: documentType,
        fileName: file.name,
        mimeType: file.type || "application/octet-stream",
        data
      })
    });
    state.complianceDocuments = payload.complianceDocuments;
    state.complianceAlerts = payload.complianceAlerts;
    if (state.customer) {
      state.customer.complianceDocuments = payload.complianceDocuments;
      state.customer.complianceAlerts = payload.complianceAlerts;
    }
    const scanIssue = payload.complianceDocument?.extracted?.aiError || payload.complianceDocument?.aiScan?.aiError || "";
    state.accountMessage = payload.complianceDocument?.expirationDate
      ? `Expiration detected: ${formatDate(payload.complianceDocument.expirationDate)}.`
      : scanIssue
        ? `Document uploaded, but scanner needs review: ${scanIssue}`
        : "Document uploaded. No expiration date was detected.";
    renderContent();
  } catch (error) {
    state.accountMessage = error.message;
    renderContent();
  }
}

async function saveMcs150Reminder(form) {
  try {
    const formData = new FormData(form);
    const payload = await api("/api/compliance/mcs150", {
      method: "POST",
      body: JSON.stringify({ lastFiledDate: formData.get("lastFiledDate") })
    });
    state.complianceDocuments = payload.complianceDocuments;
    state.complianceAlerts = payload.complianceAlerts;
    if (state.customer) {
      state.customer.complianceDocuments = payload.complianceDocuments;
      state.customer.complianceAlerts = payload.complianceAlerts;
    }
    state.accountMessage = `MCS-150 reminder saved. Next due date is ${formatDate(payload.complianceDocument.expirationDate)}.`;
    form.reset();
    renderContent();
  } catch (error) {
    state.accountMessage = error.message;
    renderContent();
  }
}

async function removeDocument(id) {
  const payload = await api(`/api/documents/${id}`, { method: "DELETE" });
  state.documents = payload.documents;
  if (state.customer) state.customer.documents = payload.documents;
  state.accountMessage = "Document removed.";
  renderContent();
}

async function renameDocument(form) {
  try {
    const payload = await api(`/api/documents/${form.dataset.renameDocument}`, {
      method: "PATCH",
      body: JSON.stringify({ fileName: new FormData(form).get("fileName") })
    });
    state.documents = payload.documents;
    if (state.customer) state.customer.documents = payload.documents;
    state.accountMessage = "File name updated.";
    renderContent();
  } catch (error) {
    state.accountMessage = error.message;
    renderContent();
  }
}

async function removeComplianceDocument(id) {
  const payload = await api(`/api/compliance/${id}`, { method: "DELETE" });
  state.complianceDocuments = payload.complianceDocuments;
  state.complianceAlerts = payload.complianceAlerts;
  if (state.customer) {
    state.customer.complianceDocuments = payload.complianceDocuments;
    state.customer.complianceAlerts = payload.complianceAlerts;
  }
  state.accountMessage = "Compliance document removed.";
  renderContent();
}

async function rescanComplianceDocument(id) {
  try {
    state.accountMessage = "Rescanning document with AI...";
    renderContent();
    const payload = await api(`/api/compliance/${id}/rescan`, { method: "POST" });
    state.complianceDocuments = payload.complianceDocuments;
    state.complianceAlerts = payload.complianceAlerts;
    const updated = payload.complianceDocuments?.find((item) => item.id === id);
    const scanIssue = updated?.extracted?.aiError || updated?.aiScan?.aiError || "";
    state.accountMessage = updated?.expirationDate
      ? `Scan complete. Renewal detected: ${formatDate(updated.expirationDate)}.`
      : scanIssue
        ? `Scan complete, but scanner needs review: ${scanIssue}`
        : "Scan complete. No renewal date was detected.";
    renderContent();
  } catch (error) {
    state.accountMessage = error.message;
    renderContent();
  }
}

async function shareSelectedComplianceDocuments() {
  try {
    const selectedIds = [...document.querySelectorAll("[data-compliance-select]:checked")].map((item) => item.dataset.complianceSelect);
    if (!selectedIds.length) throw new Error("Select at least one compliance document to share.");
    const payload = await api("/api/compliance/share", {
      method: "POST",
      body: JSON.stringify({ documentIds: selectedIds, origin: location.origin })
    });
    const subject = encodeURIComponent(`${state.customer?.businessName || "Carrier"} carrier packet`);
    const body = encodeURIComponent(`Hello,\n\nHere is the carrier packet link with the selected compliance documents:\n\n${payload.shareUrl}\n\nThank you.`);
    state.accountMessage = "Carrier packet share link created. Your email draft is opening.";
    renderContent();
    window.location.href = `mailto:?subject=${subject}&body=${body}`;
  } catch (error) {
    state.accountMessage = error.message;
    renderContent();
  }
}

function emailSelectedLoadDocuments() {
  try {
    const selectedIds = [...document.querySelectorAll("[data-document-select]:checked")].map((item) => item.dataset.documentSelect);
    if (!selectedIds.length) throw new Error("Select at least one Rate Con or BOL to email.");
    const selectedDocuments = (state.documents || []).filter((item) => selectedIds.includes(item.id));
    if (!selectedDocuments.length) throw new Error("Selected documents were not found.");
    const subject = encodeURIComponent(`${state.customer?.businessName || "Carrier"} Rate Cons/BOLs`);
    const lines = selectedDocuments.map((item) => `${documentLabel(item.type)} - ${item.fileName}\n${location.origin}/api/documents/${item.id}`);
    const body = encodeURIComponent(`Hello,\n\nHere are the selected Rate Cons/BOL documents:\n\n${lines.join("\n\n")}\n\nThank you.`);
    state.accountMessage = `${selectedDocuments.length} document${selectedDocuments.length === 1 ? "" : "s"} selected. Your email draft is opening.`;
    renderContent();
    window.location.href = `mailto:?subject=${subject}&body=${body}`;
  } catch (error) {
    state.accountMessage = error.message;
    renderContent();
  }
}

async function completeComplianceAlert(alertId) {
  try {
    const payload = await api("/api/compliance-alerts/complete", {
      method: "POST",
      body: JSON.stringify({ alertId })
    });
    state.complianceAlerts = payload.complianceAlerts;
    if (payload.customer) state.customer = payload.customer;
    state.accountMessage = "Renewal alert completed.";
    renderContent();
  } catch (error) {
    state.accountMessage = error.message;
    renderContent();
  }
}

async function saveComplianceExpiration(form) {
  try {
    const documentId = form.dataset.expirationForm;
    const document = state.complianceDocuments.find((item) => item.id === documentId);
    const rawDate = new FormData(form).get("expirationDate");
    const enteredDate = document?.type === "clearinghouseMvr" ? normalizeDateInput(rawDate) : rawDate;
    if (document?.type === "clearinghouseMvr" && !enteredDate) {
      state.accountMessage = "Enter the Clearinghouse completed date, such as 1/20/2025.";
      renderContent();
      return;
    }
    const payload = await api(`/api/compliance/${form.dataset.expirationForm}`, {
      method: "PATCH",
      body: JSON.stringify({ expirationDate: enteredDate })
    });
    state.complianceDocuments = payload.complianceDocuments;
    state.complianceAlerts = payload.complianceAlerts;
    const updated = payload.complianceDocuments?.find((item) => item.id === form.dataset.expirationForm);
    state.accountMessage = updated?.type === "clearinghouseMvr"
      ? `Clearinghouse completed date saved. Renewal is ${formatDate(updated.expirationDate)}.`
      : "Expiration date saved.";
    renderContent();
  } catch (error) {
    state.accountMessage = error.message;
    renderContent();
  }
}

function updateClearinghouseRenewalPreview(input) {
  const form = input.closest("[data-expiration-form]");
  const document = state.complianceDocuments.find((item) => item.id === form?.dataset.expirationForm);
  const preview = form?.querySelector("[data-clearinghouse-renewal-preview]");
  if (!preview || document?.type !== "clearinghouseMvr") return;
  const completedDate = normalizeDateInput(input.value);
  const renewalDate = completedDate ? addOneYear(completedDate) : "";
  preview.textContent = renewalDate ? `Renews ${formatDate(renewalDate)}` : "";
}

function refreshClearinghouseRenewalPreviews() {
  document.querySelectorAll("[data-expiration-form] input[name='expirationDate']").forEach(updateClearinghouseRenewalPreview);
}

async function saveGpsLocation(position) {
  try {
    const payload = await api("/api/route/location", {
      method: "POST",
      body: JSON.stringify({
        latitude: position.coords.latitude,
        longitude: position.coords.longitude,
        accuracy: position.coords.accuracy,
        speed: position.coords.speed,
        heading: position.coords.heading
      })
    });
    state.customer = payload.customer;
    state.accountMessage = "GPS location shared.";
    renderContent();
  } catch (error) {
    state.accountMessage = error.message;
    renderContent();
  }
}

function startGpsSharing() {
  if (!navigator.geolocation) {
    state.accountMessage = "GPS is not available on this device.";
    renderContent();
    return;
  }
  if (state.gpsWatchId) return;
  state.accountMessage = "Allow location access to start GPS sharing.";
  renderContent();
  state.gpsWatchId = navigator.geolocation.watchPosition(
    saveGpsLocation,
    (error) => {
      state.gpsWatchId = null;
      state.accountMessage = error.message || "Location permission was not allowed.";
      renderContent();
    },
    { enableHighAccuracy: true, maximumAge: 15000, timeout: 20000 }
  );
}

async function stopGpsSharing(updateServer = true) {
  if (state.gpsWatchId) {
    navigator.geolocation.clearWatch(state.gpsWatchId);
    state.gpsWatchId = null;
  }
  if (!updateServer || !state.customer) return;
  try {
    const payload = await api("/api/route/location/stop", { method: "POST" });
    state.customer = payload.customer;
    state.accountMessage = "GPS sharing stopped.";
    renderContent();
  } catch (error) {
    state.accountMessage = error.message;
    renderContent();
  }
}

document.addEventListener("click", (event) => {
  const navButton = event.target.closest("[data-view]");
  const shortcut = event.target.closest("[data-view-shortcut]");
  const deleteButton = event.target.closest("[data-delete]");
  const authModeButton = event.target.closest("[data-auth-mode]");
  const planButton = event.target.closest("[data-plan]");
  const workspacePlanButton = event.target.closest("[data-workspace-plan]");
  const deleteTruckButton = event.target.closest("[data-delete-truck]");
  const deleteDriverButton = event.target.closest("[data-delete-driver]");
  const resendDriverButton = event.target.closest("[data-resend-driver]");
  const cancelDriverButton = event.target.closest("[data-cancel-driver]");
  const changeDriverRoleButton = event.target.closest("[data-change-driver-role]");
  const resetDriverMfaButton = event.target.closest("[data-reset-driver-mfa]");
  const suspendDriverButton = event.target.closest("[data-suspend-driver]");
  const reactivateDriverButton = event.target.closest("[data-reactivate-driver]");
  const forceDriverPasswordButton = event.target.closest("[data-force-driver-password]");
  const signoutDriverButton = event.target.closest("[data-signout-driver]");
  const driverHistoryButton = event.target.closest("[data-driver-history]");
  const deleteDocumentButton = event.target.closest("[data-delete-document]");
  const deleteComplianceButton = event.target.closest("[data-delete-compliance]");
  const rescanComplianceButton = event.target.closest("[data-rescan-compliance]");
  const shareComplianceButton = event.target.closest("[data-share-compliance]");
  const emailSelectedDocumentsButton = event.target.closest("[data-email-selected-documents]");
  const completeAlertButton = event.target.closest("[data-complete-alert]");
  const openTripButton = event.target.closest("[data-open-trip]");
  const copyReferralButton = event.target.closest("[data-copy-referral]");
  const saveExpenseAmountButton = event.target.closest("[data-save-expense-amount]");
  const markPaidButton = event.target.closest("[data-mark-first-paid]");
  const stripeCheckoutButton = event.target.closest("[data-stripe-checkout]");
  const plaidLinkButton = event.target.closest("[data-plaid-link]");
  const mfaSetupButton = event.target.closest("[data-mfa-setup]");
  const gpsToggleButton = event.target.closest("[data-gps-toggle]");
  const revenueViewButton = event.target.closest("[data-revenue-view]");
  const revokeSupportAccessButton = event.target.closest("[data-revoke-support-access]");
  const closeEntryDialogButton = event.target.closest("[data-close-entry-dialog]");
  if (navButton) setView(navButton.dataset.view);
  if (shortcut) setView(shortcut.dataset.viewShortcut);
  if (deleteButton) deleteEntry(deleteButton.dataset.delete);
  if (saveExpenseAmountButton) saveExpenseAmount(saveExpenseAmountButton.closest("[data-expense-amount-form]"));
  if (authModeButton) setAuthMode(authModeButton.dataset.authMode);
  if (planButton) updatePlan(planButton.dataset.plan);
  if (workspacePlanButton) selectWorkspacePlan(workspacePlanButton.dataset.workspacePlan);
  if (deleteTruckButton) removeTruck(deleteTruckButton.dataset.deleteTruck);
  if (deleteDriverButton) removeDriver(deleteDriverButton.dataset.deleteDriver);
  if (resendDriverButton) resendDriverInvite(resendDriverButton.dataset.resendDriver);
  if (cancelDriverButton) cancelDriverInvite(cancelDriverButton.dataset.cancelDriver);
  if (changeDriverRoleButton) changeDriverRole(changeDriverRoleButton.dataset.changeDriverRole);
  if (resetDriverMfaButton) accountAccessAction(resetDriverMfaButton.dataset.resetDriverMfa, "reset-mfa");
  if (suspendDriverButton) accountAccessAction(suspendDriverButton.dataset.suspendDriver, "suspend");
  if (reactivateDriverButton) accountAccessAction(reactivateDriverButton.dataset.reactivateDriver, "reactivate");
  if (forceDriverPasswordButton) accountAccessAction(forceDriverPasswordButton.dataset.forceDriverPassword, "force-password-reset");
  if (signoutDriverButton) accountAccessAction(signoutDriverButton.dataset.signoutDriver, "signout");
  if (driverHistoryButton) showDriverHistory(driverHistoryButton.dataset.driverHistory);
  if (deleteDocumentButton) removeDocument(deleteDocumentButton.dataset.deleteDocument);
  if (deleteComplianceButton) removeComplianceDocument(deleteComplianceButton.dataset.deleteCompliance);
  if (rescanComplianceButton) rescanComplianceDocument(rescanComplianceButton.dataset.rescanCompliance);
  if (shareComplianceButton) shareSelectedComplianceDocuments();
  if (emailSelectedDocumentsButton) emailSelectedLoadDocuments();
  if (completeAlertButton) completeComplianceAlert(completeAlertButton.dataset.completeAlert);
  if (openTripButton) setView("rateCons");
  if (copyReferralButton) {
    navigator.clipboard?.writeText(copyReferralButton.dataset.copyReferral);
    state.accountMessage = "Referral link copied.";
    refreshAffiliate();
  }
  if (markPaidButton) markFirstMonthPaid();
  if (stripeCheckoutButton) startStripeCheckout(stripeCheckoutButton.dataset.stripeCheckout);
  if (plaidLinkButton) startPlaidLink();
  if (revokeSupportAccessButton) revokeSupportAccess(revokeSupportAccessButton.dataset.revokeSupportAccess);
  if (event.target.closest("[data-sign-out]")) signOut();
  if (event.target.closest("#mobileMenuBtn")) setMobileNavOpen(true);
  if (event.target.closest("#mobileNavBackdrop")) setMobileNavOpen(false);
  if (closeEntryDialogButton) dialog.close();
  if (mfaSetupButton) startMfaSetup().catch((error) => {
    state.accountMessage = error.message;
    renderContent();
  });
  if (gpsToggleButton) {
    if (gpsToggleButton.dataset.gpsToggle === "start") startGpsSharing();
    if (gpsToggleButton.dataset.gpsToggle === "stop") stopGpsSharing();
  }
  if (revenueViewButton) {
    state.dashboardRevenueView = revenueViewButton.dataset.revenueView;
    renderDashboard();
  }
});

document.addEventListener("submit", (event) => {
  if (event.target.id === "entryForm") {
    addEntry(event);
  }
  if (event.target.id === "truckForm") {
    event.preventDefault();
    addTruck(event.target);
  }
  if (event.target.id === "driverForm") {
    event.preventDefault();
    inviteDriver(event.target);
  }
  if (event.target.id === "paymentForm") {
    event.preventDefault();
    updatePaymentInfo(event.target);
  }
  if (event.target.id === "mfaEnableForm") {
    event.preventDefault();
    enableMfa(event).catch((error) => {
      state.accountMessage = error.message;
      renderContent();
    });
  }
  if (event.target.id === "supportIssueForm") {
    event.preventDefault();
    submitSupportIssue(event.target);
  }
  if (event.target.id === "documentForm") {
    event.preventDefault();
    uploadDocument(event.target);
  }
  if (event.target.id === "receiptForm") {
    event.preventDefault();
    uploadReceipt(event.target);
  }
  if (event.target.id === "driverProfileForm") {
    event.preventDefault();
    updateDriverProfile(event.target);
  }
  if (event.target.id === "driverDelayForm") {
    event.preventDefault();
    reportDriverDelay(event.target);
  }
  if (event.target.id === "complianceForm") {
    event.preventDefault();
    uploadComplianceDocument(event.target);
  }
  if (event.target.id === "mcs150Form") {
    event.preventDefault();
    saveMcs150Reminder(event.target);
  }
  if (event.target.matches("[data-expiration-form]")) {
    event.preventDefault();
    saveComplianceExpiration(event.target);
  }
  if (event.target.matches("[data-rename-document]")) {
    event.preventDefault();
    renameDocument(event.target);
  }
});

document.addEventListener("input", (event) => {
  if (event.target.id === "searchInput") {
    state.query = event.target.value;
    renderContent();
  }
  if (event.target.matches("[data-cpm-input]")) updateCostPerMileCalculator();
  if (event.target.matches("[data-expiration-form] input[name='expirationDate']")) updateClearinghouseRenewalPreview(event.target);
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Enter" && event.target.matches("[data-expense-amount-form] input[name='amount']")) {
    event.preventDefault();
    saveExpenseAmount(event.target.closest("[data-expense-amount-form]"));
  }
});

document.addEventListener("change", (event) => {
  if (event.target.id === "dateRangeFilter") {
    state.dateRange = event.target.value;
    renderContent();
  }
  if (event.target.id === "reportYearFilter") {
    state.reportYear = event.target.value;
    renderContent();
  }
  if (event.target.id === "dashboardRevenueYear") {
    state.dashboardRevenueYear = event.target.value;
    renderDashboard();
  }
  if (event.target.matches("[data-cpm-input]")) updateCostPerMileCalculator();
  if (event.target.id === "entryType") toggleTripFields();
});

document.querySelector("#quickAddBtn").addEventListener("click", () => openEntryDialog());
document.querySelector("#exportBtn").addEventListener("click", exportRecords);
togglePassword.addEventListener("click", () => {
  const showing = authPassword.type === "text";
  authPassword.type = showing ? "password" : "text";
  togglePassword.textContent = showing ? "Show" : "Hide";
  togglePassword.setAttribute("aria-pressed", String(!showing));
});
forgotPasswordBtn.addEventListener("click", () => {
  (async () => {
    const formData = new FormData(authForm);
    const email = normalizeEmail(formData.get("email"));
    if (!email) {
      authError.textContent = "Enter your email address first.";
      return;
    }
    const payload = await api("/api/password-reset/request", {
      method: "POST",
      body: JSON.stringify({ email })
    });
    authError.textContent = payload.resetUrl
      ? `${payload.message} ${payload.resetUrl}`
      : payload.message;
  })().catch((error) => {
    authError.textContent = error.message;
  });
});
verifyMfaBtn.addEventListener("click", () => {
  verifyMfaChallenge().catch((error) => {
    authError.textContent = error.message;
  });
});
authForm.addEventListener("submit", (event) => {
  event.preventDefault();
  (async () => {
    try {
      authSubmit.disabled = true;
      authError.textContent = "";
      const path = state.authMode === "signup" ? "/api/signup" : "/api/login";
      const formData = new FormData(authForm);
      const payload = await api(path, {
        method: "POST",
        body: JSON.stringify({
          businessName: formData.get("businessName"),
          dotNumber: formData.get("dotNumber"),
          companyPhone: formData.get("companyPhone"),
          companyAddress: formData.get("companyAddress"),
          adminName: formData.get("adminName"),
          adminRole: formData.get("adminRole"),
          email: normalizeEmail(formData.get("email")),
          password: formData.get("password"),
          subscriptionTier: formData.get("subscriptionTier"),
          referralCode: formData.get("referralCode"),
          acceptedPolicies: formData.has("acceptedPolicies"),
          rememberMe: formData.has("rememberMe")
        })
      });
      if (payload.mfaRequired) {
        showMfaChallenge(payload, formData.has("rememberMe"));
        return;
      }
      authForm.reset();
      if (state.authMode === "signup") {
        setAuthMode("signin");
        authError.textContent = payload.verifyUrl
          ? `Account created. Verify the administrator email before signing in: ${payload.verifyUrl}`
          : "Account created. Verify the administrator email before signing in.";
        return;
      }
      showDashboard(payload.customer, payload.records);
    } catch (error) {
      authError.textContent = error.message;
    } finally {
      authSubmit.disabled = false;
    }
  })();
});

document.addEventListener("change", (event) => {
  if (event.target.matches("[data-permission-role]")) updateInvitePermissionEditor(event.target);
});

renderIcons();
loadEnvironment();
restoreSession();

